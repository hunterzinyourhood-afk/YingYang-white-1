import { mediaStore } from "../../lib/chatroom.js";

// GET /api/chatroom/media/:key — serves uploaded avatars, banners and chat photos.
export default async (_req: Request, context: { params: Record<string, string> }) => {
  const key = context.params.key;
  if (!/^[a-z]+-[a-f0-9]{24}\.(png|jpg|gif|webp)$/.test(key || "")) return new Response("Not found", { status: 404 });
  const entry = await mediaStore().getWithMetadata(key, { type: "arrayBuffer" });
  if (!entry) return new Response("Not found", { status: 404 });
  return new Response(entry.data, {
    headers: {
      "Content-Type": String(entry.metadata.contentType || "application/octet-stream"),
      // Keys are random and never reused, so the file can be cached forever.
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
};

export const config = { path: "/api/chatroom/media/:key" };
