import { and, asc, desc, eq, gt, inArray, isNull, lt, ne, notInArray, or, sql, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import { chatMessages, chatUsers } from "../../db/schema.js";
import {
  LINK_PATTERN,
  MAX_XP,
  NEW_ACCOUNT_MESSAGE,
  NO_IMAGE_PERMS_MESSAGE,
  XP_PER_MESSAGE,
  type ChatUser,
  deleteMedia,
  getAuthedUser,
  isMuted,
  isNewAccount,
  isStaff,
  isVerified,
  mediaUrl,
  mutedMessage,
  notAllowed,
  privateProfile,
  publicProfile,
  readJson,
  saveImage,
  unauthorized,
  validGifUrl,
} from "../../lib/chatroom.js";
import { blockedIdsFor, checkText, getRoomSettings, logAction } from "../../lib/moderation.js";
import { hit, tooMany } from "../../lib/ratelimit.js";
import { canDelete, flagFiltered, openReportCount, reactionsFor, snippet, usersById, type Reaction } from "../../lib/social.js";

const PAGE_SIZE = 50;
const MAX_LENGTH = 4000;
const RECENT_WINDOW = 100;

type Message = typeof chatMessages.$inferSelect;

// Messages this viewer may see: nothing from people they blocked, and filter-hidden messages only for their author and staff.
function visibleTo(viewer: ChatUser, blocked: number[]): SQL | undefined {
  const parts: (SQL | undefined)[] = [];
  if (blocked.length) parts.push(notInArray(chatMessages.userId, blocked));
  if (!isStaff(viewer)) parts.push(or(isNull(chatMessages.hiddenAt), eq(chatMessages.userId, viewer.id)));
  return parts.length ? and(...parts) : undefined;
}

// Short previews of the messages being replied to.
async function replyPreviews(rows: Message[], viewer: ChatUser, blocked: number[]) {
  const ids = [...new Set(rows.map((m) => m.replyToId).filter((id): id is number => id != null))];
  const out = new Map<number, unknown>();
  if (!ids.length) return out;
  const targets = await db
    .select({ message: chatMessages, author: chatUsers })
    .from(chatMessages)
    .innerJoin(chatUsers, eq(chatMessages.userId, chatUsers.id))
    .where(inArray(chatMessages.id, ids));
  for (const { message, author } of targets) {
    const isBlocked = blocked.includes(author.id);
    const hidden = !!message.hiddenAt && !isStaff(viewer) && author.id !== viewer.id;
    out.set(message.id, {
      id: message.id,
      authorId: author.id,
      username: author.username,
      nameColor: author.nameColor,
      content: isBlocked ? null : hidden ? null : snippet(message.content, 120),
      note: isBlocked ? "Message from someone you blocked" : hidden ? "Message hidden by the filter" : null,
      attachment: !!(message.imageKey || message.gifUrl),
    });
  }
  return out;
}

function toJson(message: Message, author: ChatUser, replies: Map<number, unknown>, reactions: Map<number, Reaction[]>) {
  return {
    id: message.id,
    content: message.content,
    image: mediaUrl(message.imageKey),
    gif: message.gifUrl,
    createdAt: message.createdAt,
    author: publicProfile(author),
    hidden: !!message.hiddenAt,
    replyTo: message.replyToId != null ? replies.get(message.replyToId) ?? { id: message.replyToId, deleted: true } : null,
    reactions: reactions.get(message.id) ?? [],
  };
}

async function loadMessages(viewer: ChatUser, blocked: number[], where: SQL | undefined, newestFirst: boolean, limit: number) {
  const rows = await db
    .select({ message: chatMessages, author: chatUsers })
    .from(chatMessages)
    .innerJoin(chatUsers, eq(chatMessages.userId, chatUsers.id))
    .where(and(where, visibleTo(viewer, blocked)))
    .orderBy(newestFirst ? desc(chatMessages.id) : asc(chatMessages.id))
    .limit(limit);
  if (newestFirst) rows.reverse();
  const replies = await replyPreviews(rows.map((r) => r.message), viewer, blocked);
  const reactions = await reactionsFor("messageId", rows.map((r) => r.message.id), viewer.id);
  return rows.map(({ message, author }) => toJson(message, author, replies, reactions));
}

// GET    /api/chatroom/messages            → latest messages
// GET    /api/chatroom/messages?after=ID   → messages newer than ID (polling) + reactions/deletions for recent ones
// GET    /api/chatroom/messages?before=ID  → older history (scrolling up)
// POST   /api/chatroom/messages            → send (multipart: content, image?, gif?, replyTo?) — photos & GIFs need the Verified role
// DELETE /api/chatroom/messages?id=ID      → delete your own message (staff can delete anyone's)
export default async (req: Request) => {
  const user = await getAuthedUser(req);
  if (!user) return unauthorized();

  if (req.method === "GET") {
    const url = new URL(req.url);
    const after = Number(url.searchParams.get("after"));
    const before = Number(url.searchParams.get("before"));
    const blocked = await blockedIdsFor(user.id);

    await db.update(chatUsers).set({ lastSeen: sql`now()` }).where(eq(chatUsers.id, user.id));

    let messages;
    if (Number.isInteger(before) && before > 0) {
      messages = await loadMessages(user, blocked, lt(chatMessages.id, before), true, PAGE_SIZE);
      return Response.json({ messages, hasMore: messages.length === PAGE_SIZE }, { headers: { "Cache-Control": "no-store" } });
    }
    if (Number.isInteger(after) && after > 0) messages = await loadMessages(user, blocked, gt(chatMessages.id, after), false, 200);
    else messages = await loadMessages(user, blocked, undefined, true, PAGE_SIZE);

    // The newest visible messages, so the browser can drop deleted ones and refresh reaction counts.
    const recentRows = await db
      .select({ id: chatMessages.id })
      .from(chatMessages)
      .where(visibleTo(user, blocked))
      .orderBy(desc(chatMessages.id))
      .limit(RECENT_WINDOW);
    const recentIds = recentRows.map((r) => r.id);
    const recentReactions = await reactionsFor("messageId", recentIds, user.id);

    const typing = await db
      .select({ username: chatUsers.username })
      .from(chatUsers)
      .where(and(ne(chatUsers.id, user.id), gt(chatUsers.typingAt, sql`now() - interval '6 seconds'`), blocked.length ? notInArray(chatUsers.id, blocked) : undefined));

    // Everyone active in the chat in the last 30 seconds, staff first.
    const onlineUsers = await db
      .select()
      .from(chatUsers)
      .where(and(gt(chatUsers.lastSeen, sql`now() - interval '30 seconds'`), isNull(chatUsers.bannedAt)))
      .orderBy(sql`case ${chatUsers.role} when 'owner' then 0 when 'mod' then 1 else 2 end`, chatUsers.usernameKey)
      .limit(100);

    const room = await getRoomSettings();
    return Response.json(
      {
        messages,
        hasMore: messages.length === PAGE_SIZE && !(after > 0),
        recent: { ids: recentIds, reactions: Object.fromEntries(recentReactions) },
        typing: typing.map((t) => t.username),
        online: onlineUsers.length,
        onlineUsers: onlineUsers.map(publicProfile),
        me: privateProfile(user),
        room: { slowModeSeconds: room.slowModeSeconds, lockPhotos: room.lockPhotos },
        openReports: await openReportCount(user),
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  }

  if (req.method === "DELETE") {
    const id = Number(new URL(req.url).searchParams.get("id") ?? (await readJson(req)).id);
    if (!Number.isInteger(id)) return Response.json({ error: "Invalid request" }, { status: 400 });
    const [row] = await db.select({ message: chatMessages, author: chatUsers }).from(chatMessages).innerJoin(chatUsers, eq(chatMessages.userId, chatUsers.id)).where(eq(chatMessages.id, id));
    if (!row) return Response.json({ ok: true });
    if (!canDelete(user, row.author)) return notAllowed("You can't delete that message.");
    await db.delete(chatMessages).where(eq(chatMessages.id, id));
    await deleteMedia([row.message.imageKey]);
    if (row.author.id !== user.id) await logAction(user, "deleteMessage", row.author, `"${snippet(row.message.content, 200)}"${row.message.imageKey ? " (with photo)" : ""}`);
    return Response.json({ ok: true });
  }

  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

  if (isMuted(user)) return notAllowed(mutedMessage(user), 403, "muted");

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return Response.json({ error: "Invalid message" }, { status: 400 });
  }
  const content = String(form.get("content") ?? "").trim().slice(0, MAX_LENGTH);
  const image = form.get("image");
  const hasImage = image instanceof File && image.size > 0;
  const rawGif = form.get("gif");
  const gifUrl = rawGif ? validGifUrl(rawGif) : null;
  if (rawGif && !gifUrl) return Response.json({ error: "That doesn't look like a GIF link." }, { status: 400 });
  const replyRaw = Number(form.get("replyTo"));
  const replyToId = Number.isInteger(replyRaw) && replyRaw > 0 ? replyRaw : null;

  if (!content && !hasImage && !gifUrl) return Response.json({ error: "Message is empty." }, { status: 400 });
  if ((hasImage || gifUrl) && !isVerified(user)) return notAllowed(NO_IMAGE_PERMS_MESSAGE, 403, "no_image_perms");
  if (isNewAccount(user) && (hasImage || gifUrl || LINK_PATTERN.test(content))) return notAllowed(NEW_ACCOUNT_MESSAGE, 403, "new_account");

  const room = await getRoomSettings();
  if ((hasImage || gifUrl) && room.lockPhotos && !isStaff(user)) return notAllowed("Photos and GIFs are paused right now.", 403, "locked");

  // Light flood protection: one message per second, plus the owner's slow mode for everyone but staff.
  const gap = isStaff(user) ? 1 : Math.max(1, room.slowModeSeconds);
  const [last] = await db
    .select({ createdAt: chatMessages.createdAt })
    .from(chatMessages)
    .where(and(eq(chatMessages.userId, user.id), gt(chatMessages.createdAt, sql`now() - make_interval(secs => ${gap})`)))
    .orderBy(desc(chatMessages.id))
    .limit(1);
  if (last) {
    const wait = Math.max(1, Math.ceil((last.createdAt.getTime() + gap * 1000 - Date.now()) / 1000));
    return Response.json(
      { error: gap > 1 ? `Slow mode is on. You can send another message in ${wait} second${wait === 1 ? "" : "s"}.` : "Slow down a little!", retryAfter: wait },
      { status: 429 },
    );
  }
  const burst = await hit(`msg:${user.id}`, 20, 60);
  if (!burst.ok) return tooMany(burst.retryAfter, "You're sending messages too fast. Take a short break.");

  if (replyToId) {
    const [target] = await db.select({ id: chatMessages.id }).from(chatMessages).where(eq(chatMessages.id, replyToId));
    if (!target) return Response.json({ error: "The message you're replying to was deleted." }, { status: 400 });
  }

  let imageKey: string | null = null;
  if (hasImage) {
    const saved = await saveImage(image, "msg", 4 * 1024 * 1024);
    if ("error" in saved) return Response.json({ error: saved.error }, { status: 400 });
    imageKey = saved.key;
  }

  const matched = await checkText(content);
  const [message] = await db
    .insert(chatMessages)
    .values({ userId: user.id, content, imageKey, gifUrl, replyToId, hiddenAt: matched ? (sql`now()` as unknown as Date) : null })
    .returning();
  if (matched) await flagFiltered(user, matched, { messageId: message.id }, content);

  const [updated] = await db
    .update(chatUsers)
    .set({
      // Filtered messages don't earn XP.
      xp: matched ? chatUsers.xp : sql`least(${chatUsers.xp} + ${XP_PER_MESSAGE}, ${MAX_XP})`,
      messageCount: sql`${chatUsers.messageCount} + 1`,
      typingAt: null,
      lastSeen: sql`now()`,
    })
    .where(eq(chatUsers.id, user.id))
    .returning();

  const blocked = await blockedIdsFor(user.id);
  const replies = await replyPreviews([message], user, blocked);
  return Response.json(
    {
      message: toJson(message, updated, replies, new Map()),
      me: privateProfile(updated),
      notice: matched ? "Your message was hidden because it matched the chat filter. A mod will review it." : undefined,
    },
    { status: 201 },
  );
};

export const config = { path: "/api/chatroom/messages" };
