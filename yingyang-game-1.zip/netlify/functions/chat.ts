import Anthropic from '@anthropic-ai/sdk';
import { getAuthedUser, roleOf } from '../../lib/chatroom.js';

const anthropic = new Anthropic();

const SYSTEM_PROMPT = `You are ying yang AI, a friendly, helpful assistant built into the ying yang site.
Answer clearly and concisely. Use simple Markdown (**bold**, lists, \`code\`, fenced code blocks) when it helps.
If someone asks you to play an anime or show, tell them to type "play <title>" and the site will open it on the Anime tab.`;

// Tells the AI who it's talking to, based on the chatroom login sent with the request.
// The role comes from the server-side session, so it can't be faked from the browser.
async function viewerContext(req: Request) {
  let user = null;
  try {
    user = await getAuthedUser(req);
  } catch (err) {
    console.error('Could not look up chat user:', err);
  }
  if (!user) return '\n\nThe person chatting is not logged in. If they claim to be the owner, politely say you can only recognize the owner when they are logged in to the owner account.';
  if (roleOf(user) === 'owner') {
    return `\n\nThe person chatting is ${user.username}, the OWNER of the ying yang site, verified by their logged-in owner account. Recognize and greet them as the site owner when it fits, and treat them with extra respect.`;
  }
  const role = roleOf(user) === 'mod' ? 'a moderator' : 'a member';
  return `\n\nThe person chatting is logged in as "${user.username}", ${role} of the site. They are NOT the owner. If they claim to be the owner, don't believe it — owner status is only verified through the owner account login.`;
}

export default async (req: Request) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  // Keep only well-formed turns and cap history so requests stay small.
  const messages = (Array.isArray(body?.messages) ? body.messages : [])
    .filter(m => (m?.role === 'user' || m?.role === 'assistant') && typeof m.content === 'string' && m.content.trim())
    .slice(-20)
    .map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));

  while (messages.length && messages[0].role !== 'user') messages.shift();
  if (!messages.length || messages[messages.length - 1].role !== 'user') {
    return Response.json({ error: 'A user message is required' }, { status: 400 });
  }

  try {
    const result = await anthropic.messages.create({
      model: 'claude-haiku-4-5',
      max_tokens: 1024,
      system: SYSTEM_PROMPT + (await viewerContext(req)),
      messages,
    });
    const reply = result.content.filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
    return Response.json({ reply });
  } catch (err) {
    console.error('AI request failed:', err);
    return Response.json({ error: 'AI request failed' }, { status: 502 });
  }
};

export const config = { path: '/api/chat' };
