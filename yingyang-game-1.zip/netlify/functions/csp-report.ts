// Receives Content-Security-Policy violation reports (see the
// Content-Security-Policy-Report-Only header in netlify.toml) and logs a short summary.

const MAX_BODY_BYTES = 10 * 1024;

type Report = Record<string, unknown>;

function pick(r: Report, ...keys: string[]): string {
  for (const k of keys) {
    const v = r[k];
    if (typeof v === "string" && v) return v.slice(0, 200);
  }
  return "-";
}

export default async (req: Request) => {
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }

  let text = "";
  try {
    const reader = req.body?.getReader();
    if (reader) {
      const decoder = new TextDecoder();
      let bytes = 0;
      while (bytes < MAX_BODY_BYTES) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = value.subarray(0, MAX_BODY_BYTES - bytes);
        bytes += chunk.byteLength;
        text += decoder.decode(chunk, { stream: true });
      }
      reader.cancel().catch(() => {});
    }
  } catch {}

  // Old format: { "csp-report": {...} }. Reporting API: [{ type, body: {...} }, ...].
  const reports: Report[] = [];
  try {
    const parsed = JSON.parse(text);
    const list = Array.isArray(parsed) ? parsed : [parsed];
    for (const item of list.slice(0, 10)) {
      if (!item || typeof item !== "object") continue;
      const r = (item["csp-report"] ?? item.body ?? item) as unknown;
      if (r && typeof r === "object") reports.push(r as Report);
    }
  } catch {}

  if (reports.length) {
    for (const r of reports) {
      console.warn(
        "[csp]",
        pick(r, "effective-directive", "effectiveDirective", "violated-directive", "violatedDirective"),
        "blocked:",
        pick(r, "blocked-uri", "blockedURL"),
        "page:",
        pick(r, "document-uri", "documentURL"),
      );
    }
  } else if (text) {
    console.warn("[csp] unparsed report:", text.slice(0, 300));
  }

  return new Response(null, { status: 204 });
};

export const config = { path: "/api/csp-report" };
