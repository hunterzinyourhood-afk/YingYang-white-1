import { and, asc, desc, eq, gt, inArray, isNull, lt, or, sql, type SQL } from "drizzle-orm";
import { db } from "../../db/index.js";
import { chatDirectMessages, chatFriends, chatUsers } from "../../db/schema.js";
import {
  NEW_ACCOUNT_MESSAGE,
  type ChatUser,
  getAuthedUser,
  isMuted,
  isNewAccount,
  isOnline,
  mutedMessage,
  notAllowed,
  pairWhere,
  publicProfile,
  readJson,
  unauthorized,
} from "../../lib/chatroom.js";
import { checkText, eitherBlocked } from "../../lib/moderation.js";
import { hit, tooMany } from "../../lib/ratelimit.js";
import { flagFiltered, reactionsFor, snippet, type Reaction } from "../../lib/social.js";

const PAGE_SIZE = 50;
const MAX_LENGTH = 2000;
const RECENT_WINDOW = 100;

type DirectMessage = typeof chatDirectMessages.$inferSelect;

const between = (a: number, b: number) =>
  or(
    and(eq(chatDirectMessages.senderId, a), eq(chatDirectMessages.recipientId, b)),
    and(eq(chatDirectMessages.senderId, b), eq(chatDirectMessages.recipientId, a)),
  );

// Filter-hidden DMs are only shown to whoever sent them.
const visibleTo = (viewerId: number, otherId: number) =>
  and(between(viewerId, otherId), or(isNull(chatDirectMessages.hiddenAt), eq(chatDirectMessages.senderId, viewerId)));

async function areFriends(a: number, b: number) {
  const [row] = await db.select({ id: chatFriends.id }).from(chatFriends).where(and(pairWhere(a, b), eq(chatFriends.status, "accepted")));
  return !!row;
}

// Why `sender` can't message `recipient` right now, or null if they can.
async function dmBlocker(sender: ChatUser, recipient: ChatUser): Promise<{ error: string; code: string } | null> {
  if (recipient.bannedAt) return { error: "That account has been banned.", code: "banned" };
  if (await eitherBlocked(sender.id, recipient.id)) return { error: "You can't message this person.", code: "blocked" };
  if (isNewAccount(sender)) return { error: NEW_ACCOUNT_MESSAGE, code: "new_account" };
  if (isMuted(sender)) return { error: mutedMessage(sender), code: "muted" };
  const friends = await areFriends(sender.id, recipient.id);
  if (!friends && recipient.dmFriendsOnly) return { error: `${recipient.username} only accepts messages from friends. Add them as a friend first!`, code: "friends_only" };
  return null;
}

function toJson(m: DirectMessage, replies: Map<number, DirectMessage>, reactions: Map<number, Reaction[]>, viewerId: number) {
  const reply = m.replyToId != null ? replies.get(m.replyToId) : undefined;
  return {
    id: m.id,
    senderId: m.senderId,
    content: m.content,
    createdAt: m.createdAt,
    hidden: !!m.hiddenAt,
    replyTo:
      m.replyToId == null
        ? null
        : reply
          ? {
              id: reply.id,
              authorId: reply.senderId,
              content: reply.hiddenAt && reply.senderId !== viewerId ? null : snippet(reply.content, 120),
              note: reply.hiddenAt && reply.senderId !== viewerId ? "Message hidden by the filter" : null,
            }
          : { id: m.replyToId, deleted: true },
    reactions: reactions.get(m.id) ?? [],
  };
}

async function serialize(rows: DirectMessage[], viewerId: number) {
  const replyIds = [...new Set(rows.map((m) => m.replyToId).filter((id): id is number => id != null))];
  const replyRows = replyIds.length ? await db.select().from(chatDirectMessages).where(inArray(chatDirectMessages.id, replyIds)) : [];
  const replies = new Map(replyRows.map((r) => [r.id, r]));
  const reactions = await reactionsFor("dmId", rows.map((m) => m.id), viewerId);
  return rows.map((m) => toJson(m, replies, reactions, viewerId));
}

// GET    /api/chatroom/dms?with=ID            → latest private messages with someone (marks them read)
// GET    /api/chatroom/dms?with=ID&after=ID   → newer messages (polling) + reactions/deletions for recent ones
// GET    /api/chatroom/dms?with=ID&before=ID  → older history
// POST   /api/chatroom/dms { to, content, replyTo? } → send a private message
// DELETE /api/chatroom/dms?id=ID              → delete a private message you sent
export default async (req: Request) => {
  const user = await getAuthedUser(req);
  if (!user) return unauthorized();

  if (req.method === "GET") {
    const url = new URL(req.url);
    const otherId = Number(url.searchParams.get("with"));
    const after = Number(url.searchParams.get("after"));
    const before = Number(url.searchParams.get("before"));
    if (!Number.isInteger(otherId)) return Response.json({ error: "Invalid request" }, { status: 400 });
    const [other] = await db.select().from(chatUsers).where(eq(chatUsers.id, otherId));
    if (!other) return Response.json({ error: "That user doesn't exist." }, { status: 404 });

    await db.update(chatUsers).set({ lastSeen: sql`now()` }).where(eq(chatUsers.id, user.id));

    let rows;
    let where: SQL | undefined;
    if (Number.isInteger(after) && after > 0) {
      rows = await db.select().from(chatDirectMessages).where(and(visibleTo(user.id, otherId), gt(chatDirectMessages.id, after))).orderBy(asc(chatDirectMessages.id)).limit(200);
    } else {
      where = Number.isInteger(before) && before > 0 ? and(visibleTo(user.id, otherId), lt(chatDirectMessages.id, before)) : visibleTo(user.id, otherId);
      rows = (await db.select().from(chatDirectMessages).where(where).orderBy(desc(chatDirectMessages.id)).limit(PAGE_SIZE)).reverse();
    }

    await db
      .update(chatDirectMessages)
      .set({ readAt: sql`now()` })
      .where(and(eq(chatDirectMessages.senderId, otherId), eq(chatDirectMessages.recipientId, user.id), isNull(chatDirectMessages.readAt)));

    const recentRows = await db
      .select({ id: chatDirectMessages.id })
      .from(chatDirectMessages)
      .where(visibleTo(user.id, otherId))
      .orderBy(desc(chatDirectMessages.id))
      .limit(RECENT_WINDOW);
    const recentIds = recentRows.map((r) => r.id);
    const blocker = await dmBlocker(user, other);

    return Response.json(
      {
        user: { ...publicProfile(other), online: isOnline(other) },
        friends: await areFriends(user.id, otherId),
        canSend: !blocker,
        cantSendReason: blocker?.error ?? null,
        messages: await serialize(rows, user.id),
        hasMore: !(after > 0) && rows.length === PAGE_SIZE,
        recent: { ids: recentIds, reactions: Object.fromEntries(await reactionsFor("dmId", recentIds, user.id)) },
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  }

  if (req.method === "DELETE") {
    const id = Number(new URL(req.url).searchParams.get("id"));
    if (!Number.isInteger(id)) return Response.json({ error: "Invalid request" }, { status: 400 });
    const [row] = await db.select().from(chatDirectMessages).where(eq(chatDirectMessages.id, id));
    if (!row) return Response.json({ ok: true });
    if (row.senderId !== user.id) return notAllowed("You can only delete messages you sent.");
    await db.delete(chatDirectMessages).where(eq(chatDirectMessages.id, id));
    return Response.json({ ok: true });
  }

  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

  const body = await readJson<{ to?: unknown; content?: unknown; replyTo?: unknown }>(req);
  const to = Number(body.to);
  const content = typeof body.content === "string" ? body.content.trim().slice(0, MAX_LENGTH) : "";
  if (!Number.isInteger(to) || to === user.id) return Response.json({ error: "Invalid recipient" }, { status: 400 });
  if (!content) return Response.json({ error: "Message is empty." }, { status: 400 });

  const [recipient] = await db.select().from(chatUsers).where(eq(chatUsers.id, to));
  if (!recipient) return Response.json({ error: "That user doesn't exist." }, { status: 404 });
  const blocker = await dmBlocker(user, recipient);
  if (blocker) return notAllowed(blocker.error, 403, blocker.code);

  const [last] = await db
    .select({ id: chatDirectMessages.id })
    .from(chatDirectMessages)
    .where(and(eq(chatDirectMessages.senderId, user.id), gt(chatDirectMessages.createdAt, sql`now() - interval '1 second'`)))
    .limit(1);
  if (last) return Response.json({ error: "Slow down a little!" }, { status: 429 });
  const burst = await hit(`dm:${user.id}`, 30, 60);
  if (!burst.ok) return tooMany(burst.retryAfter, "You're sending messages too fast. Take a short break.");

  let replyToId: number | null = null;
  const replyRaw = Number(body.replyTo);
  if (Number.isInteger(replyRaw) && replyRaw > 0) {
    const [target] = await db.select({ id: chatDirectMessages.id }).from(chatDirectMessages).where(and(eq(chatDirectMessages.id, replyRaw), between(user.id, to)));
    if (!target) return Response.json({ error: "The message you're replying to was deleted." }, { status: 400 });
    replyToId = target.id;
  }

  const matched = await checkText(content);
  const [message] = await db
    .insert(chatDirectMessages)
    .values({ senderId: user.id, recipientId: to, content, replyToId, hiddenAt: matched ? (sql`now()` as unknown as Date) : null })
    .returning();
  if (matched) await flagFiltered(user, matched, { dmId: message.id }, content);
  await db.update(chatUsers).set({ lastSeen: sql`now()` }).where(eq(chatUsers.id, user.id));
  const [json] = await serialize([message], user.id);
  return Response.json(
    { message: json, notice: matched ? "Your message was hidden because it matched the chat filter. A mod will review it." : undefined },
    { status: 201 },
  );
};

export const config = { path: "/api/chatroom/dms" };
