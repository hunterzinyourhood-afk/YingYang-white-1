import { and, eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { chatBlocks, chatFriends, chatUsers } from "../../db/schema.js";
import { getAuthedUser, pairWhere, readJson, unauthorized } from "../../lib/chatroom.js";
import { hit, tooMany } from "../../lib/ratelimit.js";

// POST   /api/chatroom/blocks { userId } → block someone: hides their messages, ends any friendship and stops DMs and friend requests both ways
// DELETE /api/chatroom/blocks { userId } → unblock
export default async (req: Request) => {
  const user = await getAuthedUser(req);
  if (!user) return unauthorized();
  if (req.method !== "POST" && req.method !== "DELETE") return Response.json({ error: "Method not allowed" }, { status: 405 });

  const otherId = Number((await readJson(req)).userId);
  if (!Number.isInteger(otherId) || otherId === user.id) return Response.json({ error: "Pick someone else." }, { status: 400 });

  if (req.method === "DELETE") {
    await db.delete(chatBlocks).where(and(eq(chatBlocks.blockerId, user.id), eq(chatBlocks.blockedId, otherId)));
    return Response.json({ blocked: false });
  }

  const limit = await hit(`block:${user.id}`, 30, 3600);
  if (!limit.ok) return tooMany(limit.retryAfter);
  const [other] = await db.select({ id: chatUsers.id }).from(chatUsers).where(eq(chatUsers.id, otherId));
  if (!other) return Response.json({ error: "That user doesn't exist." }, { status: 404 });
  await db.insert(chatBlocks).values({ blockerId: user.id, blockedId: otherId }).onConflictDoNothing();
  await db.delete(chatFriends).where(pairWhere(user.id, otherId));
  return Response.json({ blocked: true });
};

export const config = { path: "/api/chatroom/blocks" };
