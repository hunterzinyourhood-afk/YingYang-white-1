import { and, count, eq, inArray, isNull, notInArray, or } from "drizzle-orm";
import { db } from "../../db/index.js";
import { chatDirectMessages, chatFriends, chatUsers } from "../../db/schema.js";
import { getAuthedUser, isOnline, notAllowed, pairWhere, publicProfile, readJson, unauthorized } from "../../lib/chatroom.js";
import { blockedIdsFor, eitherBlocked } from "../../lib/moderation.js";
import { hit } from "../../lib/ratelimit.js";

// Each account can send this many new friend requests per day.
const DAILY_FRIEND_REQUESTS = 20;

// GET    /api/chatroom/friends            → friends (with unread DM counts), incoming/outgoing requests,
//                                            message requests from non-friends, and people you blocked
// POST   /api/chatroom/friends { userId } → send a friend request (or accept theirs)
// DELETE /api/chatroom/friends { userId } → remove a friend, decline or cancel a request
export default async (req: Request) => {
  const user = await getAuthedUser(req);
  if (!user) return unauthorized();

  if (req.method === "GET") {
    const blocked = await blockedIdsFor(user.id);
    const rows = await db
      .select()
      .from(chatFriends)
      .where(or(eq(chatFriends.requesterId, user.id), eq(chatFriends.addresseeId, user.id)));

    const unreadRows = await db
      .select({ senderId: chatDirectMessages.senderId, n: count() })
      .from(chatDirectMessages)
      .where(and(eq(chatDirectMessages.recipientId, user.id), isNull(chatDirectMessages.readAt), isNull(chatDirectMessages.hiddenAt), blocked.length ? notInArray(chatDirectMessages.senderId, blocked) : undefined))
      .groupBy(chatDirectMessages.senderId);
    const unread = new Map(unreadRows.map((r) => [r.senderId, Number(r.n)]));

    const otherIds = rows.map((r) => (r.requesterId === user.id ? r.addresseeId : r.requesterId));
    const friendIds = new Set(otherIds);
    const strangerIds = [...unread.keys()].filter((id) => !friendIds.has(id));
    const lookup = [...otherIds, ...strangerIds, ...blocked];
    const users = lookup.length ? await db.select().from(chatUsers).where(inArray(chatUsers.id, lookup)) : [];
    const byId = new Map(users.map((u) => [u.id, u]));
    const profile = (u: (typeof users)[number]) => ({ ...publicProfile(u), online: isOnline(u) });

    const friends = [];
    const incoming = [];
    const outgoing = [];
    for (const r of rows) {
      const other = byId.get(r.requesterId === user.id ? r.addresseeId : r.requesterId);
      if (!other) continue;
      if (r.status === "accepted") friends.push({ ...profile(other), unread: unread.get(other.id) ?? 0 });
      else if (r.addresseeId === user.id) incoming.push(profile(other));
      else outgoing.push(profile(other));
    }
    friends.sort((a, b) => Number(b.online) - Number(a.online) || a.username.localeCompare(b.username));
    const messageRequests = strangerIds
      .map((id) => byId.get(id))
      .filter((u): u is NonNullable<typeof u> => !!u && !u.bannedAt)
      .map((u) => ({ ...profile(u), unread: unread.get(u.id) ?? 0 }));
    const blockedUsers = blocked.map((id) => byId.get(id)).filter((u): u is NonNullable<typeof u> => !!u).map(publicProfile);
    return Response.json({ friends, incoming, outgoing, messageRequests, blocked: blockedUsers }, { headers: { "Cache-Control": "no-store" } });
  }

  if (req.method !== "POST" && req.method !== "DELETE") return Response.json({ error: "Method not allowed" }, { status: 405 });

  const otherId = Number((await readJson(req)).userId);
  if (!Number.isInteger(otherId) || otherId === user.id) return Response.json({ error: "Pick someone else." }, { status: 400 });

  if (req.method === "DELETE") {
    await db.delete(chatFriends).where(pairWhere(user.id, otherId));
    return Response.json({ status: "none" });
  }

  const [other] = await db.select({ id: chatUsers.id, bannedAt: chatUsers.bannedAt }).from(chatUsers).where(eq(chatUsers.id, otherId));
  if (!other || other.bannedAt) return Response.json({ error: "That user doesn't exist." }, { status: 404 });
  if (await eitherBlocked(user.id, otherId)) return notAllowed("You can't send a friend request to this person.", 403, "blocked");

  const [existing] = await db.select().from(chatFriends).where(pairWhere(user.id, otherId));
  if (existing?.status === "accepted") return Response.json({ status: "friends" });
  if (existing && existing.addresseeId === user.id) {
    // They already asked us — accept.
    await db.update(chatFriends).set({ status: "accepted" }).where(eq(chatFriends.id, existing.id));
    return Response.json({ status: "friends" });
  }
  if (!existing) {
    const cap = await hit(`friendreq:${user.id}`, DAILY_FRIEND_REQUESTS, 24 * 60 * 60);
    if (!cap.ok) return Response.json({ error: `You can send up to ${DAILY_FRIEND_REQUESTS} friend requests a day. Try again tomorrow.` }, { status: 429 });
    await db.insert(chatFriends).values({ requesterId: user.id, addresseeId: otherId }).onConflictDoNothing();
  }
  return Response.json({ status: "outgoing" });
};

export const config = { path: "/api/chatroom/friends" };
