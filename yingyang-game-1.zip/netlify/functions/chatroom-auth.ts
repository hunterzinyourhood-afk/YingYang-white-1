import { eq, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { chatSessions, chatUsers } from "../../db/schema.js";
import {
  isOwnerName as isOwnerKey,
  ownerAccountFor,
  PASSWORD_RULES,
  RESERVED_NAME_MESSAGE,
  TAKEN_MESSAGE,
  bearerToken,
  getAuthedUser,
  hashPassword,
  hashToken,
  isOwnerPassword,
  newToken,
  privateProfile,
  startSession,
  unauthorized,
  usernameKey,
  validPassword,
  validateUsername,
  verifyPassword,
} from "../../lib/chatroom.js";

const MAX_FAILED_LOGINS = 5;
const LOCK_MINUTES = 5;
const WRONG_LOGIN = "Wrong username or password.";

async function readBody(req: Request): Promise<{ username?: unknown; password?: unknown }> {
  try {
    return await req.json();
  } catch {
    return {};
  }
}

// POST /api/chatroom/register { username, password } → creates an account and logs it in.
// POST /api/chatroom/login    { username, password } → logs in to an existing account.
// POST /api/chatroom/logout   (Bearer token)         → ends this device's session.
// GET  /api/chatroom/me       (Bearer token)         → the logged-in user's profile.
export default async (req: Request) => {
  const action = new URL(req.url).pathname.split("/").pop();

  if (action === "me") {
    if (req.method !== "GET") return Response.json({ error: "Method not allowed" }, { status: 405 });
    const user = await getAuthedUser(req);
    if (!user) return unauthorized();
    return Response.json({ user: privateProfile(user) }, { headers: { "Cache-Control": "no-store" } });
  }

  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

  if (action === "logout") {
    const token = bearerToken(req);
    if (token) await db.delete(chatSessions).where(eq(chatSessions.tokenHash, await hashToken(token)));
    return new Response(null, { status: 204 });
  }

  const body = await readBody(req);

  if (action === "login") {
    const name = typeof body.username === "string" ? body.username : "";
    const password = typeof body.password === "string" ? body.password : "";
    if (!name.trim() || !password) return Response.json({ error: "Enter your username and password." }, { status: 400 });

    const key = usernameKey(name.replace(/\s+/g, " "));
    const isOwnerName = isOwnerKey(key);
    const ownerPassword = isOwnerName && (await isOwnerPassword(key, password));
    let [user] = await db.select().from(chatUsers).where(eq(chatUsers.usernameKey, key));

    // The owner account is created the first time it logs in with the owner password.
    if (!user && ownerPassword) {
      const [created] = await db
        .insert(chatUsers)
        .values({ username: ownerAccountFor(key)!.username, usernameKey: key, tokenHash: await hashToken(newToken()), passwordHash: await hashPassword(password), role: "owner" })
        .onConflictDoNothing({ target: chatUsers.usernameKey })
        .returning();
      if (created) {
        const token = await startSession(created.id);
        return Response.json({ token, user: privateProfile(created) }, { status: 201 });
      }
      [user] = await db.select().from(chatUsers).where(eq(chatUsers.usernameKey, key));
    }
    if (!user) return Response.json({ error: WRONG_LOGIN }, { status: 401 });
    if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
      return Response.json({ error: `Too many wrong passwords. Try again in ${LOCK_MINUTES} minutes.` }, { status: 429 });
    }
    if (!user.passwordHash && !isOwnerName) {
      return Response.json(
        { error: "This account was made before passwords were added. Log in on the original device and set a password in Settings." },
        { status: 401 },
      );
    }
    // Only the owner password unlocks the owner name until the owner has claimed it.
    const valid = isOwnerName
      ? ownerPassword || (user.role === "owner" && (await verifyPassword(password, user.passwordHash)))
      : await verifyPassword(password, user.passwordHash);
    if (!valid) {
      const failed = user.failedLogins + 1;
      await db
        .update(chatUsers)
        .set(
          failed >= MAX_FAILED_LOGINS
            ? { failedLogins: 0, lockedUntil: sql`now() + make_interval(mins => ${LOCK_MINUTES})` as unknown as Date }
            : { failedLogins: failed },
        )
        .where(eq(chatUsers.id, user.id));
      return Response.json({ error: WRONG_LOGIN }, { status: 401 });
    }

    if (user.bannedAt) return Response.json({ error: "You have been banned from the chat." }, { status: 403 });
    if (user.kickedUntil && user.kickedUntil.getTime() > Date.now()) {
      const mins = Math.max(1, Math.ceil((user.kickedUntil.getTime() - Date.now()) / 60000));
      return Response.json({ error: `You were kicked from the chat. You can come back in ${mins} minute${mins === 1 ? "" : "s"}.` }, { status: 403 });
    }

    if (isOwnerName && user.role !== "owner") {
      // First owner login on an existing account with an owner name: claim it and sign out anyone else using it.
      await db.delete(chatSessions).where(eq(chatSessions.userId, user.id));
      [user] = await db
        .update(chatUsers)
        .set({ role: "owner", passwordHash: await hashPassword(password), failedLogins: 0, lockedUntil: null })
        .where(eq(chatUsers.id, user.id))
        .returning();
    } else if (user.failedLogins || user.lockedUntil) {
      await db.update(chatUsers).set({ failedLogins: 0, lockedUntil: null }).where(eq(chatUsers.id, user.id));
    }
    const token = await startSession(user.id);
    return Response.json({ token, user: privateProfile(user) });
  }

  if (action !== "register") return Response.json({ error: "Not found" }, { status: 404 });

  const username = validateUsername(body.username);
  if (!username) {
    return Response.json({ error: "Usernames must be 2–20 characters: letters, numbers, spaces, _ or ." }, { status: 400 });
  }
  if (!validPassword(body.password)) return Response.json({ error: PASSWORD_RULES }, { status: 400 });
  const isOwnerName = isOwnerKey(usernameKey(username));
  if (isOwnerName && !(await isOwnerPassword(usernameKey(username), body.password))) {
    return Response.json({ error: RESERVED_NAME_MESSAGE }, { status: 403 });
  }

  const [user] = await db
    .insert(chatUsers)
    .values({
      username,
      usernameKey: usernameKey(username),
      // Legacy single-token column; sessions now live in chat_sessions, so this is just a unique placeholder.
      tokenHash: await hashToken(newToken()),
      passwordHash: await hashPassword(body.password),
      role: isOwnerName ? "owner" : "member",
    })
    .onConflictDoNothing({ target: chatUsers.usernameKey })
    .returning();

  if (!user) {
    return Response.json({ error: isOwnerName ? "That account already exists — log in instead." : TAKEN_MESSAGE }, { status: 409 });
  }
  const token = await startSession(user.id);
  return Response.json({ token, user: privateProfile(user) }, { status: 201 });
};

export const config = {
  path: ["/api/chatroom/register", "/api/chatroom/login", "/api/chatroom/logout", "/api/chatroom/me"],
};
