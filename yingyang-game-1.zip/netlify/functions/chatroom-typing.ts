import { eq, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { chatUsers } from "../../db/schema.js";
import { getAuthedUser, unauthorized } from "../../lib/chatroom.js";

// POST /api/chatroom/typing { typing: boolean } — others see "X is typing…" for ~6 seconds.
export default async (req: Request) => {
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });
  const user = await getAuthedUser(req);
  if (!user) return unauthorized();
  let body: { typing?: unknown } = {};
  try {
    body = await req.json();
  } catch {}
  await db
    .update(chatUsers)
    .set({ typingAt: body.typing === false ? null : sql`now()`, lastSeen: sql`now()` })
    .where(eq(chatUsers.id, user.id));
  return new Response(null, { status: 204 });
};

export const config = { path: "/api/chatroom/typing" };
