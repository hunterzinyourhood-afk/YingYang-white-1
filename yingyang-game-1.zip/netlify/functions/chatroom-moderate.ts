import { desc, eq, isNotNull, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { chatSessions, chatUsers } from "../../db/schema.js";
import {
  MAX_LEVEL,
  MAX_XP,
  XP_PER_LEVEL,
  getAuthedUser,
  hashToken,
  isStaff,
  newToken,
  publicProfile,
  roleOf,
  unauthorized,
} from "../../lib/chatroom.js";

const KICK_MINUTES = 5;
const ACTIONS = ["kick", "ban", "unban", "mod", "unmod", "verify", "unverify", "setLevel", "addXp"] as const;
type Action = (typeof ACTIONS)[number];

// GET  /api/chatroom/moderate                      → banned users (owner & mods only)
// POST /api/chatroom/moderate { userId, action }   → kick | ban | unban | verify | unverify (owner & mods),
//                                                    mod | unmod (owner only)
//                     { userId, action: "setLevel", level }  → set someone's level (owner & mods)
//                     { userId, action: "addXp", amount }    → give someone XP (owner & mods)
export default async (req: Request) => {
  const user = await getAuthedUser(req);
  if (!user) return unauthorized();
  if (!isStaff(user)) return Response.json({ error: "Only the owner and mods can do that." }, { status: 403 });

  if (req.method === "GET") {
    const banned = await db.select().from(chatUsers).where(isNotNull(chatUsers.bannedAt)).orderBy(desc(chatUsers.bannedAt)).limit(100);
    return Response.json({ banned: banned.map(publicProfile) }, { headers: { "Cache-Control": "no-store" } });
  }
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });

  let body: { userId?: unknown; action?: unknown; level?: unknown; amount?: unknown } = {};
  try {
    body = await req.json();
  } catch {}
  const action = body.action as Action;
  const targetId = Number(body.userId);
  if (!ACTIONS.includes(action) || !Number.isInteger(targetId)) return Response.json({ error: "Invalid request" }, { status: 400 });

  const [target] = await db.select().from(chatUsers).where(eq(chatUsers.id, targetId));
  if (!target) return Response.json({ error: "That user doesn't exist." }, { status: 404 });
  if (target.id === user.id) return Response.json({ error: "You can't do that to yourself." }, { status: 400 });

  const actorRole = roleOf(user);
  const targetRole = roleOf(target);
  if (targetRole === "owner") return Response.json({ error: "Nobody can moderate the owner." }, { status: 403 });
  if ((action === "mod" || action === "unmod") && actorRole !== "owner") {
    return Response.json({ error: "Only the owner can give or remove the Mod role." }, { status: 403 });
  }
  if (targetRole === "mod" && actorRole !== "owner") return Response.json({ error: "Mods can't moderate other mods." }, { status: 403 });

  let changes: Partial<typeof chatUsers.$inferInsert>;
  let endSessions = false;
  switch (action) {
    case "kick":
      changes = { kickedUntil: sql`now() + make_interval(mins => ${KICK_MINUTES})` as unknown as Date, typingAt: null };
      endSessions = true;
      break;
    case "ban":
      // Banned users also lose the Mod role.
      changes = { bannedAt: sql`now()` as unknown as Date, role: "member", typingAt: null };
      endSessions = true;
      break;
    case "unban":
      changes = { bannedAt: null, kickedUntil: null };
      break;
    case "mod":
      if (target.bannedAt) return Response.json({ error: "Unban them first." }, { status: 400 });
      changes = { role: "mod" };
      break;
    case "unmod":
      changes = { role: "member" };
      break;
    case "verify":
    case "unverify":
      changes = { imagePerms: action === "verify" };
      break;
    case "setLevel": {
      const level = Number(body.level);
      if (!Number.isInteger(level) || level < 1 || level > MAX_LEVEL) {
        return Response.json({ error: `Pick a level from 1 to ${MAX_LEVEL}.` }, { status: 400 });
      }
      changes = { xp: (level - 1) * XP_PER_LEVEL };
      break;
    }
    case "addXp": {
      const amount = Number(body.amount);
      if (!Number.isInteger(amount) || amount < 1 || amount > MAX_XP) {
        return Response.json({ error: `Pick an amount of XP from 1 to ${MAX_XP}.` }, { status: 400 });
      }
      changes = { xp: sql`least(${chatUsers.xp} + ${amount}, ${MAX_XP})` as unknown as number };
      break;
    }
  }

  // Also rotate the legacy single-device token so old pre-session logins end too.
  if (endSessions) changes.tokenHash = await hashToken(newToken());
  const [updated] = await db.update(chatUsers).set(changes).where(eq(chatUsers.id, target.id)).returning();
  if (endSessions) await db.delete(chatSessions).where(eq(chatSessions.userId, target.id));
  return Response.json({ user: publicProfile(updated) });
};

export const config = { path: "/api/chatroom/moderate" };
