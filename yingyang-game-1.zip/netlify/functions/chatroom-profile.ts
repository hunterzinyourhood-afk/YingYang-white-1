import { and, eq, ne, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { chatSessions, chatUsers } from "../../db/schema.js";
import {
  DECORATIONS,
  NAME_CHANGE_COOLDOWN_MS,
  NAME_EFFECTS,
  NAME_FONTS,
  isOwnerName,
  RESERVED_NAME_MESSAGE,
  PROFILE_EFFECTS,
  PASSWORD_RULES,
  bearerToken,
  hashPassword,
  hashToken,
  validPassword,
  verifyPassword,
  TAKEN_MESSAGE,
  getAuthedUser,
  mediaStore,
  privateProfile,
  saveImage,
  unauthorized,
  usernameKey,
  validateUsername,
} from "../../lib/chatroom.js";

const isColor = (v: unknown): v is string => typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v);
const clip = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : undefined);

// PATCH /api/chatroom/profile (JSON)      → update name, colours, bio, status, decoration, effects…
// POST  /api/chatroom/profile (multipart) → upload avatar or banner (field "kind": avatar|banner, "file")
//                                           or remove one (field "remove": avatar|banner)
export default async (req: Request) => {
  const user = await getAuthedUser(req);
  if (!user) return unauthorized();

  if (req.method === "POST") {
    let form: FormData;
    try {
      form = await req.formData();
    } catch {
      return Response.json({ error: "Invalid upload" }, { status: 400 });
    }
    const remove = form.get("remove");
    const kind = remove ?? form.get("kind");
    if (kind !== "avatar" && kind !== "banner") return Response.json({ error: "Unknown upload type" }, { status: 400 });
    const column = kind === "avatar" ? "avatarKey" : "bannerKey";
    const oldKey = user[column];

    let newKey: string | null = null;
    if (!remove) {
      const saved = await saveImage(form.get("file"), kind, 3 * 1024 * 1024);
      if ("error" in saved) return Response.json({ error: saved.error }, { status: 400 });
      newKey = saved.key;
    }
    const [updated] = await db.update(chatUsers).set({ [column]: newKey }).where(eq(chatUsers.id, user.id)).returning();
    if (oldKey) await mediaStore().delete(oldKey).catch(() => {});
    return Response.json({ user: privateProfile(updated) });
  }

  if (req.method !== "PATCH") return Response.json({ error: "Method not allowed" }, { status: 405 });

  let body: Record<string, unknown> = {};
  try {
    body = await req.json();
  } catch {}

  const changes: Partial<typeof chatUsers.$inferInsert> = {};
  let passwordChanged = false;

  if (body.newPassword !== undefined) {
    if (!validPassword(body.newPassword)) return Response.json({ error: PASSWORD_RULES }, { status: 400 });
    if (user.passwordHash && !(await verifyPassword(String(body.currentPassword ?? ""), user.passwordHash))) {
      return Response.json({ error: "Your current password is wrong." }, { status: 403 });
    }
    changes.passwordHash = await hashPassword(body.newPassword);
    passwordChanged = true;
  }

  if (body.username !== undefined && body.username !== user.username) {
    const username = validateUsername(body.username);
    if (!username) {
      return Response.json({ error: "Usernames must be 2–20 characters: letters, numbers, spaces, _ or ." }, { status: 400 });
    }
    if (username !== user.username) {
      if (user.role === "owner") return Response.json({ error: "Owner accounts keep their name." }, { status: 403 });
      if (isOwnerName(usernameKey(username))) return Response.json({ error: RESERVED_NAME_MESSAGE }, { status: 403 });
      if (user.nameChangedAt && Date.now() - user.nameChangedAt.getTime() < NAME_CHANGE_COOLDOWN_MS) {
        const next = new Date(user.nameChangedAt.getTime() + NAME_CHANGE_COOLDOWN_MS);
        return Response.json(
          { error: `You can only change your name once a week. Try again on ${next.toDateString()}.` },
          { status: 429 },
        );
      }
      const key = usernameKey(username);
      const [taken] = await db
        .select({ id: chatUsers.id })
        .from(chatUsers)
        .where(and(eq(chatUsers.usernameKey, key), ne(chatUsers.id, user.id)));
      if (taken) return Response.json({ error: TAKEN_MESSAGE }, { status: 409 });
      changes.username = username;
      changes.usernameKey = key;
      changes.nameChangedAt = sql`now()` as unknown as Date;
    }
  }

  for (const field of ["nameColor", "bannerColor", "themePrimary", "themeAccent"] as const) {
    if (isColor(body[field])) changes[field] = body[field] as string;
  }
  if (body.nameGradient === null || body.nameGradient === "") changes.nameGradient = null;
  else if (isColor(body.nameGradient)) changes.nameGradient = body.nameGradient;
  if (typeof body.nameFont === "string" && body.nameFont in NAME_FONTS) changes.nameFont = body.nameFont;
  if (typeof body.decoration === "string" && body.decoration in DECORATIONS) changes.decoration = body.decoration;
  if (typeof body.profileEffect === "string" && body.profileEffect in PROFILE_EFFECTS) changes.profileEffect = body.profileEffect;
  if (typeof body.nameEffect === "string" && body.nameEffect in NAME_EFFECTS) changes.nameEffect = body.nameEffect;
  const bio = clip(body.bio, 190);
  if (bio !== undefined) changes.bio = bio;
  const statusText = clip(body.statusText, 60);
  if (statusText !== undefined) changes.statusText = statusText;
  const statusEmoji = clip(body.statusEmoji, 8);
  if (statusEmoji !== undefined) changes.statusEmoji = statusEmoji;

  if (!Object.keys(changes).length) return Response.json({ user: privateProfile(user) });

  try {
    const [updated] = await db.update(chatUsers).set(changes).where(eq(chatUsers.id, user.id)).returning();
    if (passwordChanged) {
      // Log out every other device; this one stays signed in.
      const current = await hashToken(bearerToken(req)!);
      await db.delete(chatSessions).where(and(eq(chatSessions.userId, user.id), ne(chatSessions.tokenHash, current)));
    }
    return Response.json({ user: privateProfile(updated) });
  } catch (err) {
    // Unique index race: someone grabbed the name between the check and the update.
    if (String((err as { code?: string })?.code) === "23505") return Response.json({ error: TAKEN_MESSAGE }, { status: 409 });
    throw err;
  }
};

export const config = { path: "/api/chatroom/profile" };
