import { sql, lt, gt, count, eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { presence } from "../../db/schema.js";

// A visitor counts as "online" if they sent a heartbeat in the last 45 seconds
// (the client pings every 20 seconds).

export default async (req: Request) => {
  if (req.method === "POST") {
    let body: { sessionId?: unknown; leaving?: unknown } = {};
    try {
      body = await req.json();
    } catch {}
    const sessionId = typeof body.sessionId === "string" ? body.sessionId.slice(0, 64) : "";
    if (!/^[a-zA-Z0-9-]{8,64}$/.test(sessionId)) {
      return Response.json({ error: "Invalid sessionId" }, { status: 400 });
    }

    if (body.leaving) {
      await db.delete(presence).where(eq(presence.sessionId, sessionId));
    } else {
      await db
        .insert(presence)
        .values({ sessionId, lastSeen: sql`now()` })
        .onConflictDoUpdate({ target: presence.sessionId, set: { lastSeen: sql`now()` } });
    }

    // Prune stale sessions so the table stays small.
    await db.delete(presence).where(lt(presence.lastSeen, sql`now() - interval '10 minutes'`));
  } else if (req.method !== "GET") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }

  const [row] = await db
    .select({ online: count() })
    .from(presence)
    .where(gt(presence.lastSeen, sql`now() - interval '45 seconds'`));

  return Response.json({ online: Number(row?.online ?? 0) }, { headers: { "Cache-Control": "no-store" } });
};

export const config = { path: "/api/presence" };
