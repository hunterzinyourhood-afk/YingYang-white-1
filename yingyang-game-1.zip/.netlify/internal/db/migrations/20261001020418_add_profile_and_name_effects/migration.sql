ALTER TABLE "chat_users" ADD COLUMN "profile_effect" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_users" ADD COLUMN "name_effect" text DEFAULT 'none' NOT NULL;