CREATE TABLE "chat_messages" (
	"id" serial PRIMARY KEY,
	"user_id" integer NOT NULL,
	"content" text DEFAULT '' NOT NULL,
	"image_key" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_users" (
	"id" serial PRIMARY KEY,
	"username" text NOT NULL,
	"username_key" text NOT NULL UNIQUE,
	"token_hash" text NOT NULL UNIQUE,
	"xp" integer DEFAULT 0 NOT NULL,
	"message_count" integer DEFAULT 0 NOT NULL,
	"avatar_key" text,
	"banner_key" text,
	"banner_color" text DEFAULT '#5865f2' NOT NULL,
	"name_color" text DEFAULT '#ffffff' NOT NULL,
	"name_gradient" text,
	"name_font" text DEFAULT 'default' NOT NULL,
	"decoration" text DEFAULT 'none' NOT NULL,
	"theme_primary" text DEFAULT '#1e1f22' NOT NULL,
	"theme_accent" text DEFAULT '#2b2d31' NOT NULL,
	"bio" text DEFAULT '' NOT NULL,
	"status_emoji" text DEFAULT '' NOT NULL,
	"status_text" text DEFAULT '' NOT NULL,
	"image_perms" boolean DEFAULT false NOT NULL,
	"name_changed_at" timestamp,
	"typing_at" timestamp,
	"last_seen" timestamp DEFAULT now() NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "chat_messages_user_idx" ON "chat_messages" ("user_id");--> statement-breakpoint
ALTER TABLE "chat_messages" ADD CONSTRAINT "chat_messages_user_id_chat_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;