CREATE TABLE "chat_sessions" (
	"token_hash" text PRIMARY KEY,
	"user_id" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "chat_users" ADD COLUMN "password_hash" text;--> statement-breakpoint
ALTER TABLE "chat_users" ADD COLUMN "failed_logins" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_users" ADD COLUMN "locked_until" timestamp;--> statement-breakpoint
CREATE INDEX "chat_sessions_user_idx" ON "chat_sessions" ("user_id");--> statement-breakpoint
ALTER TABLE "chat_sessions" ADD CONSTRAINT "chat_sessions_user_id_chat_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;