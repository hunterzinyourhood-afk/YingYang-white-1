CREATE TABLE "presence" (
	"session_id" text PRIMARY KEY,
	"last_seen" timestamp DEFAULT now() NOT NULL
);
