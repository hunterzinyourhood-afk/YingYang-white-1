CREATE TABLE "chat_blocks" (
	"blocker_id" integer,
	"blocked_id" integer,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "chat_blocks_pkey" PRIMARY KEY("blocker_id","blocked_id")
);
--> statement-breakpoint
CREATE TABLE "chat_filters" (
	"id" serial PRIMARY KEY,
	"kind" text NOT NULL,
	"pattern" text NOT NULL,
	"created_by_id" integer,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_mod_log" (
	"id" serial PRIMARY KEY,
	"actor_id" integer,
	"actor_name" text NOT NULL,
	"action" text NOT NULL,
	"target_id" integer,
	"target_name" text,
	"details" text DEFAULT '' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_reactions" (
	"id" serial PRIMARY KEY,
	"message_id" integer,
	"dm_id" integer,
	"user_id" integer NOT NULL,
	"emoji" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_reports" (
	"id" serial PRIMARY KEY,
	"reporter_id" integer,
	"target_user_id" integer,
	"message_id" integer,
	"dm_id" integer,
	"kind" text NOT NULL,
	"reason" text NOT NULL,
	"details" text DEFAULT '' NOT NULL,
	"snapshot" text DEFAULT '' NOT NULL,
	"against_staff" boolean DEFAULT false NOT NULL,
	"status" text DEFAULT 'open' NOT NULL,
	"resolved_by_id" integer,
	"resolution" text,
	"resolved_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_reset_codes" (
	"id" serial PRIMARY KEY,
	"user_id" integer NOT NULL,
	"code_hash" text NOT NULL,
	"issued_by_id" integer,
	"expires_at" timestamp NOT NULL,
	"used_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_settings" (
	"key" text PRIMARY KEY,
	"value" text NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "rate_limits" (
	"key" text PRIMARY KEY,
	"count" integer DEFAULT 0 NOT NULL,
	"reset_at" timestamp NOT NULL
);
--> statement-breakpoint
ALTER TABLE "chat_direct_messages" ADD COLUMN "reply_to_id" integer;--> statement-breakpoint
ALTER TABLE "chat_direct_messages" ADD COLUMN "hidden_at" timestamp;--> statement-breakpoint
ALTER TABLE "chat_messages" ADD COLUMN "reply_to_id" integer;--> statement-breakpoint
ALTER TABLE "chat_messages" ADD COLUMN "hidden_at" timestamp;--> statement-breakpoint
ALTER TABLE "chat_users" ADD COLUMN "muted_until" timestamp;--> statement-breakpoint
ALTER TABLE "chat_users" ADD COLUMN "dm_friends_only" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_users" ADD COLUMN "rules_accepted_at" timestamp;--> statement-breakpoint
CREATE INDEX "chat_blocks_blocked_idx" ON "chat_blocks" ("blocked_id");--> statement-breakpoint
CREATE INDEX "chat_dms_created_idx" ON "chat_direct_messages" ("created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "chat_filters_pattern_idx" ON "chat_filters" ("kind","pattern");--> statement-breakpoint
CREATE INDEX "chat_messages_created_idx" ON "chat_messages" ("created_at");--> statement-breakpoint
CREATE INDEX "chat_mod_log_created_idx" ON "chat_mod_log" ("created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "chat_reactions_message_idx" ON "chat_reactions" ("message_id","user_id","emoji");--> statement-breakpoint
CREATE UNIQUE INDEX "chat_reactions_dm_idx" ON "chat_reactions" ("dm_id","user_id","emoji");--> statement-breakpoint
CREATE INDEX "chat_reports_status_idx" ON "chat_reports" ("status","created_at");--> statement-breakpoint
CREATE INDEX "chat_reset_codes_user_idx" ON "chat_reset_codes" ("user_id");--> statement-breakpoint
ALTER TABLE "chat_blocks" ADD CONSTRAINT "chat_blocks_blocker_id_chat_users_id_fkey" FOREIGN KEY ("blocker_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_blocks" ADD CONSTRAINT "chat_blocks_blocked_id_chat_users_id_fkey" FOREIGN KEY ("blocked_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_direct_messages" ADD CONSTRAINT "chat_direct_messages_reply_to_id_chat_direct_messages_id_fkey" FOREIGN KEY ("reply_to_id") REFERENCES "chat_direct_messages"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_filters" ADD CONSTRAINT "chat_filters_created_by_id_chat_users_id_fkey" FOREIGN KEY ("created_by_id") REFERENCES "chat_users"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_messages" ADD CONSTRAINT "chat_messages_reply_to_id_chat_messages_id_fkey" FOREIGN KEY ("reply_to_id") REFERENCES "chat_messages"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_mod_log" ADD CONSTRAINT "chat_mod_log_actor_id_chat_users_id_fkey" FOREIGN KEY ("actor_id") REFERENCES "chat_users"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_mod_log" ADD CONSTRAINT "chat_mod_log_target_id_chat_users_id_fkey" FOREIGN KEY ("target_id") REFERENCES "chat_users"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_reactions" ADD CONSTRAINT "chat_reactions_message_id_chat_messages_id_fkey" FOREIGN KEY ("message_id") REFERENCES "chat_messages"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_reactions" ADD CONSTRAINT "chat_reactions_dm_id_chat_direct_messages_id_fkey" FOREIGN KEY ("dm_id") REFERENCES "chat_direct_messages"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_reactions" ADD CONSTRAINT "chat_reactions_user_id_chat_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_reports" ADD CONSTRAINT "chat_reports_reporter_id_chat_users_id_fkey" FOREIGN KEY ("reporter_id") REFERENCES "chat_users"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_reports" ADD CONSTRAINT "chat_reports_target_user_id_chat_users_id_fkey" FOREIGN KEY ("target_user_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_reports" ADD CONSTRAINT "chat_reports_message_id_chat_messages_id_fkey" FOREIGN KEY ("message_id") REFERENCES "chat_messages"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_reports" ADD CONSTRAINT "chat_reports_dm_id_chat_direct_messages_id_fkey" FOREIGN KEY ("dm_id") REFERENCES "chat_direct_messages"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_reports" ADD CONSTRAINT "chat_reports_resolved_by_id_chat_users_id_fkey" FOREIGN KEY ("resolved_by_id") REFERENCES "chat_users"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "chat_reset_codes" ADD CONSTRAINT "chat_reset_codes_user_id_chat_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_reset_codes" ADD CONSTRAINT "chat_reset_codes_issued_by_id_chat_users_id_fkey" FOREIGN KEY ("issued_by_id") REFERENCES "chat_users"("id") ON DELETE SET NULL;