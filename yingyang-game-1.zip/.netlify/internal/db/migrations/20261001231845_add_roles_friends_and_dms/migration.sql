CREATE TABLE "chat_direct_messages" (
	"id" serial PRIMARY KEY,
	"sender_id" integer NOT NULL,
	"recipient_id" integer NOT NULL,
	"content" text NOT NULL,
	"read_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "chat_friends" (
	"id" serial PRIMARY KEY,
	"requester_id" integer NOT NULL,
	"addressee_id" integer NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "chat_users" ADD COLUMN "role" text DEFAULT 'member' NOT NULL;--> statement-breakpoint
ALTER TABLE "chat_users" ADD COLUMN "banned_at" timestamp;--> statement-breakpoint
ALTER TABLE "chat_users" ADD COLUMN "kicked_until" timestamp;--> statement-breakpoint
CREATE INDEX "chat_dms_sender_recipient_idx" ON "chat_direct_messages" ("sender_id","recipient_id");--> statement-breakpoint
CREATE INDEX "chat_dms_recipient_idx" ON "chat_direct_messages" ("recipient_id");--> statement-breakpoint
CREATE UNIQUE INDEX "chat_friends_pair_idx" ON "chat_friends" ("requester_id","addressee_id");--> statement-breakpoint
CREATE INDEX "chat_friends_addressee_idx" ON "chat_friends" ("addressee_id");--> statement-breakpoint
ALTER TABLE "chat_direct_messages" ADD CONSTRAINT "chat_direct_messages_sender_id_chat_users_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_direct_messages" ADD CONSTRAINT "chat_direct_messages_recipient_id_chat_users_id_fkey" FOREIGN KEY ("recipient_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_friends" ADD CONSTRAINT "chat_friends_requester_id_chat_users_id_fkey" FOREIGN KEY ("requester_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "chat_friends" ADD CONSTRAINT "chat_friends_addressee_id_chat_users_id_fkey" FOREIGN KEY ("addressee_id") REFERENCES "chat_users"("id") ON DELETE CASCADE;