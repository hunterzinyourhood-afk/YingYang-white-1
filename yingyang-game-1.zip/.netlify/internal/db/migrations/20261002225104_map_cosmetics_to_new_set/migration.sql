-- Map the old profile effects and avatar decorations onto the new canvas/SVG set (approved by the owner).
UPDATE "chat_users" SET "profile_effect" = CASE "profile_effect"
  WHEN 'sparkles' THEN 'starfield'
  WHEN 'snow' THEN 'snowfall'
  WHEN 'hearts' THEN 'sakura'
  WHEN 'stars' THEN 'starfield'
  WHEN 'sakura' THEN 'sakura'
  WHEN 'bubbles' THEN 'orbs'
  WHEN 'fire' THEN 'embers'
  WHEN 'confetti' THEN 'aurora'
  ELSE 'none'
END
WHERE "profile_effect" NOT IN ('none', 'embers', 'snowfall', 'aurora', 'starfield', 'rain', 'sakura', 'glitch', 'orbs');
--> statement-breakpoint
UPDATE "chat_users" SET "decoration" = CASE "decoration"
  WHEN 'glow' THEN 'halo'
  WHEN 'rainbow' THEN 'neon'
  WHEN 'fire' THEN 'flame'
  WHEN 'ice' THEN 'halo'
  WHEN 'gold' THEN 'halo'
  WHEN 'neon' THEN 'neon'
  WHEN 'sakura' THEN 'vines'
  ELSE 'none'
END
WHERE "decoration" NOT IN ('none', 'neon', 'flame', 'halo', 'catears', 'glitch', 'pixel', 'vines', 'crown');
