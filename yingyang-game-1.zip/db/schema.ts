import { pgTable, text, timestamp, serial, integer, boolean, index, uniqueIndex, primaryKey, type AnyPgColumn } from "drizzle-orm/pg-core";

// One row per open browser tab; last_seen is refreshed by a heartbeat.
export const presence = pgTable("presence", {
  sessionId: text("session_id").primaryKey(),
  lastSeen: timestamp("last_seen").notNull().defaultNow(),
});

// Community chat accounts. A username is claimed once; the browser keeps a secret
// token (only its hash is stored here) that identifies the account afterwards.
export const chatUsers = pgTable(
  "chat_users",
  {
    id: serial().primaryKey(),
    username: text().notNull(),
    usernameKey: text("username_key").notNull().unique(),
    tokenHash: text("token_hash").notNull().unique(),
    // PBKDF2 hash ("pbkdf2$iterations$salt$hash"); null only for accounts made before passwords existed.
    passwordHash: text("password_hash"),
    failedLogins: integer("failed_logins").notNull().default(0),
    lockedUntil: timestamp("locked_until"),
    xp: integer().notNull().default(0),
    messageCount: integer("message_count").notNull().default(0),
    avatarKey: text("avatar_key"),
    bannerKey: text("banner_key"),
    bannerColor: text("banner_color").notNull().default("#5865f2"),
    nameColor: text("name_color").notNull().default("#ffffff"),
    nameGradient: text("name_gradient"),
    nameFont: text("name_font").notNull().default("default"),
    decoration: text().notNull().default("none"),
    profileEffect: text("profile_effect").notNull().default("none"),
    nameEffect: text("name_effect").notNull().default("none"),
    themePrimary: text("theme_primary").notNull().default("#1e1f22"),
    themeAccent: text("theme_accent").notNull().default("#2b2d31"),
    bio: text().notNull().default(""),
    statusEmoji: text("status_emoji").notNull().default(""),
    statusText: text("status_text").notNull().default(""),
    // The Verified role, granted by the owner or a mod. Photos and GIFs are only allowed once it's granted.
    imagePerms: boolean("image_perms").notNull().default(false),
    // "member" (everyone is Verified), "mod" (granted by the owner) or "owner" (only the Ying Yang account).
    role: text().notNull().default("member"),
    bannedAt: timestamp("banned_at"),
    // Kicked users are logged out and can't log back in until this passes.
    kickedUntil: timestamp("kicked_until"),
    // Timed-out (muted) users can read but not send messages, DMs or reactions until this passes.
    mutedUntil: timestamp("muted_until"),
    // When false, people who aren't friends can DM this user too (blocked users and new accounts still can't).
    dmFriendsOnly: boolean("dm_friends_only").notNull().default(true),
    rulesAcceptedAt: timestamp("rules_accepted_at"),
    nameChangedAt: timestamp("name_changed_at"),
    typingAt: timestamp("typing_at"),
    lastSeen: timestamp("last_seen").notNull().defaultNow(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
);

export const chatMessages = pgTable(
  "chat_messages",
  {
    id: serial().primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => chatUsers.id, { onDelete: "cascade" }),
    content: text().notNull().default(""),
    imageKey: text("image_key"),
    // A linked GIF (Giphy, Tenor or any https .gif URL) shown under the message.
    gifUrl: text("gif_url"),
    replyToId: integer("reply_to_id").references((): AnyPgColumn => chatMessages.id, { onDelete: "set null" }),
    // Set when the word/link filter matched. Hidden messages are only shown to their author and staff.
    hiddenAt: timestamp("hidden_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("chat_messages_user_idx").on(t.userId), index("chat_messages_created_idx").on(t.createdAt)],
);

// One row per logged-in device. Only a hash of the browser's session token is stored.
export const chatSessions = pgTable(
  "chat_sessions",
  {
    tokenHash: text("token_hash").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => chatUsers.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("chat_sessions_user_idx").on(t.userId)],
);

// Friend requests. A row is "pending" until the addressee accepts, then "accepted".
export const chatFriends = pgTable(
  "chat_friends",
  {
    id: serial().primaryKey(),
    requesterId: integer("requester_id")
      .notNull()
      .references(() => chatUsers.id, { onDelete: "cascade" }),
    addresseeId: integer("addressee_id")
      .notNull()
      .references(() => chatUsers.id, { onDelete: "cascade" }),
    status: text().notNull().default("pending"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("chat_friends_pair_idx").on(t.requesterId, t.addresseeId),
    index("chat_friends_addressee_idx").on(t.addresseeId),
  ],
);

// Private messages between two friends.
export const chatDirectMessages = pgTable(
  "chat_direct_messages",
  {
    id: serial().primaryKey(),
    senderId: integer("sender_id")
      .notNull()
      .references(() => chatUsers.id, { onDelete: "cascade" }),
    recipientId: integer("recipient_id")
      .notNull()
      .references(() => chatUsers.id, { onDelete: "cascade" }),
    content: text().notNull(),
    replyToId: integer("reply_to_id").references((): AnyPgColumn => chatDirectMessages.id, { onDelete: "set null" }),
    hiddenAt: timestamp("hidden_at"),
    readAt: timestamp("read_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("chat_dms_sender_recipient_idx").on(t.senderId, t.recipientId),
    index("chat_dms_recipient_idx").on(t.recipientId),
    index("chat_dms_created_idx").on(t.createdAt),
  ],
);

// Emoji reactions on a #general message or a DM (exactly one of messageId / dmId is set).
export const chatReactions = pgTable(
  "chat_reactions",
  {
    id: serial().primaryKey(),
    messageId: integer("message_id").references(() => chatMessages.id, { onDelete: "cascade" }),
    dmId: integer("dm_id").references(() => chatDirectMessages.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => chatUsers.id, { onDelete: "cascade" }),
    emoji: text().notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("chat_reactions_message_idx").on(t.messageId, t.userId, t.emoji),
    uniqueIndex("chat_reactions_dm_idx").on(t.dmId, t.userId, t.emoji),
  ],
);

// "blocker" no longer sees "blocked"'s messages, and neither can DM or friend-request the other.
export const chatBlocks = pgTable(
  "chat_blocks",
  {
    blockerId: integer("blocker_id")
      .notNull()
      .references(() => chatUsers.id, { onDelete: "cascade" }),
    blockedId: integer("blocked_id")
      .notNull()
      .references(() => chatUsers.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.blockerId, t.blockedId] }), index("chat_blocks_blocked_idx").on(t.blockedId)],
);

// Reports from members (or the word filter, when reporterId is null) waiting in the mod queue.
// kind: "message" | "dm" | "profile" | "filter". The reported text is copied into "snapshot", so staff
// never need to open a DM conversation to review it.
export const chatReports = pgTable(
  "chat_reports",
  {
    id: serial().primaryKey(),
    reporterId: integer("reporter_id").references(() => chatUsers.id, { onDelete: "set null" }),
    targetUserId: integer("target_user_id").references(() => chatUsers.id, { onDelete: "cascade" }),
    messageId: integer("message_id").references(() => chatMessages.id, { onDelete: "set null" }),
    dmId: integer("dm_id").references(() => chatDirectMessages.id, { onDelete: "set null" }),
    kind: text().notNull(),
    reason: text().notNull(),
    details: text().notNull().default(""),
    snapshot: text().notNull().default(""),
    // Reports against the owner or a mod are only shown to the owner.
    againstStaff: boolean("against_staff").notNull().default(false),
    // "open" | "dismissed" | "actioned"
    status: text().notNull().default("open"),
    resolvedById: integer("resolved_by_id").references(() => chatUsers.id, { onDelete: "set null" }),
    resolution: text(),
    resolvedAt: timestamp("resolved_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("chat_reports_status_idx").on(t.status, t.createdAt)],
);

// Everything staff do (who, what, whom, when). Names are copied so the log survives account deletion.
export const chatModLog = pgTable(
  "chat_mod_log",
  {
    id: serial().primaryKey(),
    actorId: integer("actor_id").references(() => chatUsers.id, { onDelete: "set null" }),
    actorName: text("actor_name").notNull(),
    action: text().notNull(),
    targetId: integer("target_id").references(() => chatUsers.id, { onDelete: "set null" }),
    targetName: text("target_name"),
    details: text().notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("chat_mod_log_created_idx").on(t.createdAt)],
);

// Words and link domains the filter hides. kind: "word" | "link".
export const chatFilters = pgTable(
  "chat_filters",
  {
    id: serial().primaryKey(),
    kind: text().notNull(),
    pattern: text().notNull(),
    createdById: integer("created_by_id").references(() => chatUsers.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("chat_filters_pattern_idx").on(t.kind, t.pattern)],
);

// Room-wide switches set by the owner (slow mode, lockdown). One row per key, value stored as text.
export const chatSettings = pgTable("chat_settings", {
  key: text().primaryKey(),
  value: text().notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// One-time password reset codes handed out by the owner or a mod. Only a hash is stored.
export const chatResetCodes = pgTable(
  "chat_reset_codes",
  {
    id: serial().primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => chatUsers.id, { onDelete: "cascade" }),
    codeHash: text("code_hash").notNull(),
    issuedById: integer("issued_by_id").references(() => chatUsers.id, { onDelete: "set null" }),
    expiresAt: timestamp("expires_at").notNull(),
    usedAt: timestamp("used_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("chat_reset_codes_user_idx").on(t.userId)],
);

// Fixed-window counters used by hit() in lib/ratelimit.ts.
export const rateLimits = pgTable("rate_limits", {
  key: text().primaryKey(),
  count: integer().notNull().default(0),
  resetAt: timestamp("reset_at").notNull(),
});
