// ===== SITE SETTINGS =====
// Gear button in the sidebar / mobile nav → panel with profile customisation, appearance,
// tab cloak and privacy options. Preferences are per-browser and kept in localStorage.
(function () {
    const STORE_KEY = 'yySiteSettings';
    const ORIGINAL_TITLE = document.title;

    const PALETTES = {
        default: { label: 'Ying Yang', colors: ['#5227FF', '#FF9FFC', '#B497CF'] },
        ocean: { label: 'Ocean', colors: ['#00c6ff', '#0072ff', '#7afcff'] },
        sunset: { label: 'Sunset', colors: ['#ff5f6d', '#ffc371', '#ff9a8b'] },
        forest: { label: 'Forest', colors: ['#11998e', '#38ef7d', '#a8ff78'] },
        inferno: { label: 'Inferno', colors: ['#ff0000', '#ff7b00', '#ffd000'] },
        mono: { label: 'Mono', colors: ['#ffffff', '#888888', '#333333'] },
        gold: { label: 'Gold', colors: ['#b8860b', '#ffd76a', '#fff1a8'] },
        custom: { label: 'Custom', colors: null },
    };

    const favicon = (domain) => `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
    const CLOAKS = {
        none: { label: 'Off', title: '', icon: '' },
        classroom: { label: 'Classroom', title: 'Home', icon: favicon('classroom.google.com') },
        docs: { label: 'Google Docs', title: 'Google Docs', icon: favicon('docs.google.com') },
        drive: { label: 'Google Drive', title: 'My Drive - Google Drive', icon: favicon('drive.google.com') },
        gmail: { label: 'Gmail', title: 'Inbox - Gmail', icon: favicon('mail.google.com') },
        google: { label: 'Google', title: 'Google', icon: favicon('google.com') },
        canvas: { label: 'Canvas', title: 'Dashboard', icon: favicon('instructure.com') },
        clever: { label: 'Clever', title: 'Clever | Portal', icon: favicon('clever.com') },
        khan: { label: 'Khan Academy', title: 'Dashboard | Khan Academy', icon: favicon('khanacademy.org') },
        custom: { label: 'Custom', title: '', icon: '' },
    };

    const DEFAULTS = {
        bgEnabled: true,
        bgPalette: 'default',
        bgCustom: ['#5227FF', '#FF9FFC', '#B497CF'],
        cursor: true,
        reduceMotion: false,
        cloak: 'none',
        cloakTitle: '',
        cloakIcon: '',
        cloakOnHide: false,
        panicKey: '',
        panicUrl: 'https://classroom.google.com',
        confirmLeave: false,
    };

    let settings = Object.assign({}, DEFAULTS);
    try { Object.assign(settings, JSON.parse(localStorage.getItem(STORE_KEY) || '{}')); } catch (e) {}

    function save() {
        try { localStorage.setItem(STORE_KEY, JSON.stringify(settings)); } catch (e) {}
    }

    const $ = (id) => document.getElementById(id);
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const isColor = (v) => /^#[0-9a-fA-F]{6}$/.test(v);

    // ---------- background (read by the LiquidEther module script) ----------
    function backgroundColors() {
        if (settings.bgPalette === 'custom') return settings.bgCustom.filter(isColor).length === 3 ? settings.bgCustom : PALETTES.default.colors;
        return (PALETTES[settings.bgPalette] || PALETTES.default).colors;
    }
    window.yySiteSettings = {
        backgroundEnabled: () => settings.bgEnabled,
        backgroundColors,
    };
    function refreshBackground() {
        document.documentElement.classList.toggle('yy-no-bg', !settings.bgEnabled);
        if (typeof window.yyMountBackground === 'function') window.yyMountBackground();
    }

    // ---------- tab cloak ----------
    function cloakValues() {
        if (settings.cloak === 'custom') return { title: settings.cloakTitle.trim(), icon: settings.cloakIcon.trim() };
        return CLOAKS[settings.cloak] || CLOAKS.none;
    }
    function setFavicon(href) {
        let link = document.querySelector('link[rel="icon"]');
        if (!href) { if (link) link.remove(); return; }
        if (!link) { link = document.createElement('link'); link.rel = 'icon'; document.head.appendChild(link); }
        link.href = href;
    }
    function applyCloak() {
        const { title, icon } = cloakValues();
        const active = settings.cloak !== 'none' && (!settings.cloakOnHide || document.hidden);
        document.title = active && title ? title : ORIGINAL_TITLE;
        setFavicon(active && icon ? icon : '');
    }
    document.addEventListener('visibilitychange', () => { if (settings.cloakOnHide) applyCloak(); });

    function openAboutBlank() {
        const win = window.open('about:blank', '_blank');
        if (!win) { alert('Your browser blocked the pop-up. Allow pop-ups for this site and try again.'); return; }
        const { title, icon } = cloakValues();
        const doc = win.document;
        doc.title = settings.cloak !== 'none' && title ? title : ORIGINAL_TITLE;
        if (settings.cloak !== 'none' && icon) {
            const link = doc.createElement('link');
            link.rel = 'icon';
            link.href = icon;
            doc.head.appendChild(link);
        }
        doc.body.style.margin = '0';
        const frame = doc.createElement('iframe');
        frame.src = location.href;
        frame.style.cssText = 'border:none;width:100vw;height:100vh;display:block';
        frame.allow = 'fullscreen; autoplay; clipboard-write';
        doc.body.appendChild(frame);
    }

    // ---------- panic key & leave confirmation ----------
    const keyLabel = (k) => (k === ' ' ? 'Space' : k);
    let listeningForKey = false;
    document.addEventListener('keydown', (e) => {
        if (listeningForKey) return;
        if (!settings.panicKey || e.key !== settings.panicKey || e.ctrlKey || e.metaKey || e.altKey) return;
        // Don't fire while typing a single printable character into a text field.
        const t = e.target;
        const typing = t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
        if (typing && e.key.length === 1) return;
        e.preventDefault();
        window.onbeforeunload = null;
        location.replace(normalizeUrl(settings.panicUrl) || 'https://classroom.google.com');
    }, true);
    function normalizeUrl(v) {
        v = String(v || '').trim();
        if (!v) return '';
        return /^https?:\/\//i.test(v) ? v : 'https://' + v;
    }
    function applyLeaveConfirm() {
        window.onbeforeunload = settings.confirmLeave ? (e) => { e.preventDefault(); e.returnValue = ''; return ''; } : null;
    }

    function applyAll() {
        const root = document.documentElement;
        root.classList.toggle('yy-no-cursor', !settings.cursor);
        root.classList.toggle('yy-reduce-motion', !!settings.reduceMotion);
        root.classList.toggle('yy-no-bg', !settings.bgEnabled);
        applyCloak();
        applyLeaveConfirm();
    }
    applyAll();

    // ---------- panel ----------
    const modal = $('yySettings');
    const openButtons = document.querySelectorAll('[data-open-settings]');

    function openPanel(tab) {
        fillPanel();
        if (tab) selectTab(tab);
        modal.classList.remove('hidden');
        openButtons.forEach((b) => b.classList.add('open'));
    }
    function closePanel() {
        modal.classList.add('hidden');
        openButtons.forEach((b) => b.classList.remove('open'));
        stopListening();
    }
    window.yyOpenSettings = openPanel;
    openButtons.forEach((b) => b.addEventListener('click', (e) => { e.preventDefault(); openPanel(); }));
    openButtons.forEach((b) => b.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openPanel(); } }));
    $('yySettingsClose').addEventListener('click', closePanel);
    modal.addEventListener('click', (e) => { if (e.target === modal) closePanel(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !modal.classList.contains('hidden') && !listeningForKey) closePanel(); });

    const tabTitles = { profile: 'Profile', appearance: 'Appearance', cloak: 'Tab Cloak', privacy: 'Privacy' };
    function selectTab(name) {
        modal.querySelectorAll('.yy-tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
        modal.querySelectorAll('.yy-panel').forEach((p) => p.classList.toggle('active', p.dataset.panel === name));
        $('yyPanelTitle').textContent = tabTitles[name] || '';
    }
    modal.querySelectorAll('.yy-tab').forEach((t) => t.addEventListener('click', () => selectTab(t.dataset.tab)));

    $('yyCustomizeProfile').addEventListener('click', () => {
        closePanel();
        if (typeof window.ccOpenProfileSettings === 'function') window.ccOpenProfileSettings();
        else window.navigateTo('chat');
    });

    // Appearance
    const bgEnabled = $('yyBgEnabled'), cursorOn = $('yyCursor'), reduceMotion = $('yyReduceMotion');
    const paletteGrid = $('yyPaletteGrid'), customColors = $('yyCustomColors');
    const customInputs = [$('yyBgC1'), $('yyBgC2'), $('yyBgC3')];

    function renderPalettes() {
        paletteGrid.innerHTML = '';
        Object.entries(PALETTES).forEach(([key, p]) => {
            const colors = key === 'custom' ? settings.bgCustom : p.colors;
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'yy-swatch' + (settings.bgPalette === key ? ' active' : '');
            b.innerHTML = `<i style="background:linear-gradient(90deg,${colors.map(esc).join(',')})"></i>${esc(p.label)}`;
            b.onclick = () => { settings.bgPalette = key; save(); renderPalettes(); refreshBackground(); };
            paletteGrid.appendChild(b);
        });
        customColors.classList.toggle('hidden', settings.bgPalette !== 'custom');
    }
    bgEnabled.addEventListener('change', () => { settings.bgEnabled = bgEnabled.checked; save(); refreshBackground(); });
    cursorOn.addEventListener('change', () => { settings.cursor = cursorOn.checked; save(); applyAll(); });
    reduceMotion.addEventListener('change', () => { settings.reduceMotion = reduceMotion.checked; save(); applyAll(); });
    customInputs.forEach((inp, i) => inp.addEventListener('change', () => {
        settings.bgCustom[i] = inp.value;
        save();
        renderPalettes();
        refreshBackground();
    }));

    // Tab cloak
    const cloakGrid = $('yyCloakGrid'), cloakCustom = $('yyCloakCustom'), cloakTitle = $('yyCloakTitle'), cloakIcon = $('yyCloakIcon'), cloakOnHide = $('yyCloakOnHide');
    function renderCloaks() {
        cloakGrid.innerHTML = '';
        Object.entries(CLOAKS).forEach(([key, c]) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'yy-preset' + (settings.cloak === key ? ' active' : '');
            const icon = c.icon ? `<img src="${esc(c.icon)}" alt="">` : `<span class="yy-preset-icon">${key === 'none' ? '🚫' : '✏️'}</span>`;
            b.innerHTML = icon + esc(c.label);
            b.onclick = () => { settings.cloak = key; save(); renderCloaks(); applyCloak(); };
            cloakGrid.appendChild(b);
        });
        cloakCustom.classList.toggle('hidden', settings.cloak !== 'custom');
    }
    cloakTitle.addEventListener('input', () => { settings.cloakTitle = cloakTitle.value; save(); applyCloak(); });
    cloakIcon.addEventListener('change', () => { settings.cloakIcon = normalizeUrl(cloakIcon.value); cloakIcon.value = settings.cloakIcon; save(); applyCloak(); });
    cloakOnHide.addEventListener('change', () => { settings.cloakOnHide = cloakOnHide.checked; save(); applyCloak(); });
    $('yyAboutBlank').addEventListener('click', openAboutBlank);

    // Privacy
    const panicKeyBtn = $('yyPanicKey'), panicUrl = $('yyPanicUrl'), confirmLeave = $('yyConfirmLeave');
    function renderPanicKey() {
        panicKeyBtn.textContent = listeningForKey ? 'Press a key…' : (settings.panicKey ? keyLabel(settings.panicKey) : 'Not set');
        panicKeyBtn.classList.toggle('listening', listeningForKey);
    }
    function onKeyCapture(e) {
        e.preventDefault();
        e.stopPropagation();
        if (e.key === 'Escape') { stopListening(); return; }
        if (['Shift', 'Control', 'Alt', 'Meta', 'Tab'].includes(e.key)) return;
        settings.panicKey = e.key;
        save();
        stopListening();
    }
    function stopListening() {
        if (!listeningForKey) return;
        // Defer so the Escape that ended listening doesn't also close the panel.
        setTimeout(() => { listeningForKey = false; renderPanicKey(); }, 0);
        document.removeEventListener('keydown', onKeyCapture, true);
    }
    panicKeyBtn.addEventListener('click', () => {
        if (listeningForKey) { stopListening(); return; }
        listeningForKey = true;
        renderPanicKey();
        document.addEventListener('keydown', onKeyCapture, true);
    });
    $('yyPanicClear').addEventListener('click', () => { stopListening(); settings.panicKey = ''; save(); setTimeout(renderPanicKey, 0); });
    panicUrl.addEventListener('change', () => { settings.panicUrl = normalizeUrl(panicUrl.value); panicUrl.value = settings.panicUrl; save(); });
    confirmLeave.addEventListener('change', () => { settings.confirmLeave = confirmLeave.checked; save(); applyLeaveConfirm(); });

    $('yyResetSettings').addEventListener('click', () => {
        if (!confirm('Reset all site settings to their defaults?')) return;
        settings = Object.assign({}, DEFAULTS, { bgCustom: DEFAULTS.bgCustom.slice() });
        save();
        applyAll();
        refreshBackground();
        fillPanel();
    });

    function fillPanel() {
        bgEnabled.checked = settings.bgEnabled;
        cursorOn.checked = settings.cursor;
        reduceMotion.checked = settings.reduceMotion;
        customInputs.forEach((inp, i) => { inp.value = isColor(settings.bgCustom[i]) ? settings.bgCustom[i] : DEFAULTS.bgCustom[i]; });
        renderPalettes();
        cloakTitle.value = settings.cloakTitle;
        cloakIcon.value = settings.cloakIcon;
        cloakOnHide.checked = settings.cloakOnHide;
        renderCloaks();
        panicUrl.value = settings.panicUrl;
        confirmLeave.checked = settings.confirmLeave;
        renderPanicKey();
    }
})();
