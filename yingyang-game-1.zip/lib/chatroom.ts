import { and, eq, gt, or, sql } from "drizzle-orm";
import { getStore } from "@netlify/blobs";
import { db } from "../db/index.js";
import { chatFriends, chatSessions, chatUsers } from "../db/schema.js";

export type ChatUser = typeof chatUsers.$inferSelect;

export const TAKEN_MESSAGE = "That username is taken. Try another one.";
export const DISCORD_INVITE = "https://discord.gg/AwfYXnYhdK";
export const NO_IMAGE_PERMS_MESSAGE = `Only Verified members can send photos and GIFs. Join our Discord to get verified: ${DISCORD_INVITE}`;
export const NO_UPLOAD_PERMS_MESSAGE = `Only Verified members can upload a profile picture or banner. Join our Discord to get verified: ${DISCORD_INVITE}`;

export const XP_PER_MESSAGE = 5;
export const XP_PER_LEVEL = 250;
export const MAX_LEVEL = 100;
export const MAX_XP = (MAX_LEVEL - 1) * XP_PER_LEVEL;
export const NAME_CHANGE_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000;

export const SESSION_DAYS = 30;
// Accounts younger than this can't post links, photos or DMs until a mod or the owner verifies them.
export const NEW_ACCOUNT_MS = 24 * 60 * 60 * 1000;

// Cosmetics and the level that unlocks each one (fonts early, decorations in the middle, effects later).
// "staff" items are only for the owner and mods. Keep in sync with COSMETICS in community-chat.js.
export const NAME_FONTS: Record<string, number> = {
  default: 1, bold: 1, mono: 1, serif: 1, cursive: 1, pixel: 1,
  outfit: 2, nunito: 2, spacemono: 2, caveat: 3, playfair: 3, righteous: 3,
  bebas: 4, pacifico: 4, pressstart: 5, orbitron: 5, marker: 6, lobster: 7,
};
export const DECORATIONS: Record<string, number | "staff"> = {
  none: 1, neon: 5, halo: 6, pixel: 7, catears: 8, vines: 9, flame: 10, glitch: 12, crown: "staff",
};
export const PROFILE_EFFECTS: Record<string, number> = {
  none: 1, snowfall: 12, rain: 13, starfield: 14, sakura: 15, orbs: 16, embers: 18, aurora: 20, glitch: 22,
};
export const NAME_EFFECTS: Record<string, number> = { none: 1, glow: 1, pop: 1, neon: 3, shimmer: 4, rainbow: 6, wave: 8 };

// Whether this user may switch to `value`. Keeping what they already have equipped is always allowed.
export function cosmeticAllowed(table: Record<string, number | "staff">, value: string, current: string, u: ChatUser) {
  if (!(value in table)) return false;
  if (value === current) return true;
  const need = table[value];
  if (need === "staff") return isStaff(u);
  return isStaff(u) || levelFor(u.xp) >= need;
}

export const mediaStore = () => getStore("chatroom-media");

// Owner accounts. The names are reserved here; their password hashes live in the OWNER_PASSWORD_HASHES
// environment variable as JSON: {"Ying Yang": ["pbkdf2$…", …], "Ying_Yang_Owner": ["pbkdf2$…"]}.
// "Ying_Yang_Owner" is the secret owner login reached from the crown button on the login page.
const OWNER_USERNAMES = ["Ying Yang", "Ying_Yang_Owner"];

function ownerHashes(): Record<string, string[]> {
  try {
    const parsed = JSON.parse(process.env.OWNER_PASSWORD_HASHES || "{}");
    const out: Record<string, string[]> = {};
    for (const [name, hashes] of Object.entries(parsed)) {
      const list = Array.isArray(hashes) ? hashes : [hashes];
      out[usernameKey(name)] = list.filter((h): h is string => typeof h === "string");
    }
    return out;
  } catch {
    console.error("OWNER_PASSWORD_HASHES is not valid JSON");
    return {};
  }
}
export const RESERVED_NAME_MESSAGE = "That name is reserved for the site owner.";

// The owner account whose username matches this key, if any.
export const ownerAccountFor = (key: string) => {
  const username = OWNER_USERNAMES.find((n) => usernameKey(n) === key);
  return username ? { username, passwordHashes: ownerHashes()[key] || [] } : undefined;
};
export const isOwnerName = (key: string) => !!ownerAccountFor(key);

export async function isOwnerPassword(key: string, password: string) {
  const account = ownerAccountFor(key);
  if (!account) return false;
  for (const hash of account.passwordHashes) if (await verifyPassword(password, hash)) return true;
  return false;
}

export type Role = "owner" | "mod" | "member";
export const roleOf = (u: ChatUser): Role => (u.role === "owner" ? "owner" : u.role === "mod" ? "mod" : "member");
export const isStaff = (u: ChatUser) => roleOf(u) !== "member";
// The Verified role is handed out by the owner and mods; staff always have it. It unlocks photos and GIFs.
export const isVerified = (u: ChatUser) => isStaff(u) || u.imagePerms;
// New, unverified accounts can't send links, photos or DMs for their first 24 hours.
export const isNewAccount = (u: ChatUser) => !isVerified(u) && Date.now() - u.createdAt.getTime() < NEW_ACCOUNT_MS;
export const NEW_ACCOUNT_MESSAGE = "New accounts can't send links, photos or private messages for their first 24 hours. A mod can verify you sooner.";
export const isMuted = (u: ChatUser) => !!u.mutedUntil && u.mutedUntil.getTime() > Date.now();
export function mutedMessage(u: ChatUser) {
  const mins = Math.max(1, Math.ceil(((u.mutedUntil?.getTime() ?? 0) - Date.now()) / 60000));
  const left = mins < 60 ? `${mins} more minute${mins === 1 ? "" : "s"}` : `about ${Math.round(mins / 60)} more hour${Math.round(mins / 60) === 1 ? "" : "s"}`;
  return `You're timed out and can't send messages for ${left}.`;
}
export const LINK_PATTERN = /\b(?:https?:\/\/|www\.)\S+|\b[a-z0-9-]+\.(?:com|net|org|gg|io|co|ly|me|xyz|app|dev|tv|link|site|online|ru|info|biz)\b/i;

// Linked GIFs must be https links from Giphy/Tenor or end in .gif.
const GIF_HOSTS = /^(media\d*|i)\.giphy\.com$|^media\d*\.tenor\.com$|^c\.tenor\.com$/;
export function validGifUrl(raw: unknown): string | null {
  if (typeof raw !== "string" || raw.length > 500) return null;
  let url: URL;
  try {
    url = new URL(raw.trim());
  } catch {
    return null;
  }
  if (url.protocol !== "https:" || url.username || url.password) return null;
  return GIF_HOSTS.test(url.hostname) || /\.gif$/i.test(url.pathname) ? url.href : null;
}

export const levelFor = (xp: number) => Math.min(MAX_LEVEL, 1 + Math.floor(xp / XP_PER_LEVEL));

export const usernameKey = (name: string) => name.trim().toLowerCase();

// 2–20 characters: letters, numbers, underscores, dots and single spaces.
export function validateUsername(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const name = raw.trim().replace(/\s+/g, " ");
  return /^[A-Za-z0-9_. ]{2,20}$/.test(name) ? name : null;
}

const toHex = (bytes: Uint8Array) => Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");

export async function hashToken(token: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token));
  return toHex(new Uint8Array(digest));
}

export function newToken() {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return toHex(bytes);
}

export function bearerToken(req: Request) {
  const header = req.headers.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  return /^[a-f0-9]{64}$/.test(token) ? token : null;
}

export async function getAuthedUser(req: Request): Promise<ChatUser | null> {
  const token = bearerToken(req);
  if (!token) return null;
  const hash = await hashToken(token);
  // Sessions last 30 days from login; after that the device has to log in again.
  const [session] = await db
    .select({ user: chatUsers })
    .from(chatSessions)
    .innerJoin(chatUsers, eq(chatSessions.userId, chatUsers.id))
    .where(and(eq(chatSessions.tokenHash, hash), gt(chatSessions.createdAt, sql`now() - make_interval(days => ${SESSION_DAYS})`)));
  const user = session?.user;
  if (!user || user.bannedAt) return null;
  return user;
}

// Creates a new logged-in session for this device and returns its token.
export async function startSession(userId: number) {
  const token = newToken();
  await db.insert(chatSessions).values({ tokenHash: await hashToken(token), userId });
  return token;
}

export const PASSWORD_RULES = "Passwords must be 6–72 characters.";
export const validPassword = (p: unknown): p is string => typeof p === "string" && p.length >= 6 && p.length <= 72;

const PBKDF2_ITERATIONS = 100_000;

async function pbkdf2(password: string, salt: Uint8Array, iterations: number) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: salt as BufferSource, iterations }, key, 256);
  return toHex(new Uint8Array(bits));
}

export async function hashPassword(password: string) {
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);
  return `pbkdf2$${PBKDF2_ITERATIONS}$${toHex(salt)}$${await pbkdf2(password, salt, PBKDF2_ITERATIONS)}`;
}

export async function verifyPassword(password: string, stored: string | null) {
  const [scheme, iter, saltHex, hash] = (stored || "").split("$");
  if (scheme !== "pbkdf2" || !saltHex || !hash) return false;
  const salt = new Uint8Array(saltHex.match(/../g)!.map((h) => parseInt(h, 16)));
  const candidate = await pbkdf2(password, salt, Number(iter));
  // Constant-time comparison.
  let diff = candidate.length ^ hash.length;
  for (let i = 0; i < candidate.length && i < hash.length; i++) diff |= candidate.charCodeAt(i) ^ hash.charCodeAt(i);
  return diff === 0;
}

// Friend rows linking the two users, in either direction.
export const pairWhere = (a: number, b: number) =>
  or(
    and(eq(chatFriends.requesterId, a), eq(chatFriends.addresseeId, b)),
    and(eq(chatFriends.requesterId, b), eq(chatFriends.addresseeId, a)),
  );

export const unauthorized = () => Response.json({ error: "Please log in to chat." }, { status: 401 });

export async function readJson<T = Record<string, unknown>>(req: Request): Promise<T> {
  try {
    const body = await req.json();
    return body && typeof body === "object" ? body : ({} as T);
  } catch {
    return {} as T;
  }
}

export const mediaUrl = (key: string | null) => (key ? `/api/chatroom/media/${key}` : null);

export async function deleteMedia(keys: (string | null | undefined)[]) {
  const store = mediaStore();
  await Promise.all(keys.filter((k): k is string => !!k).map((k) => store.delete(k).catch(() => {})));
}

// What everyone else is allowed to see about a user.
export function publicProfile(u: ChatUser) {
  return {
    id: u.id,
    username: u.username,
    avatar: mediaUrl(u.avatarKey),
    banner: mediaUrl(u.bannerKey),
    bannerColor: u.bannerColor,
    nameColor: u.nameColor,
    nameGradient: u.nameGradient,
    nameFont: u.nameFont,
    decoration: u.decoration,
    profileEffect: u.profileEffect,
    nameEffect: u.nameEffect,
    themePrimary: u.themePrimary,
    themeAccent: u.themeAccent,
    bio: u.bio,
    statusEmoji: u.statusEmoji,
    statusText: u.statusText,
    role: roleOf(u),
    verified: isVerified(u),
    banned: !!u.bannedAt,
    level: levelFor(u.xp),
    xp: u.xp,
    messageCount: u.messageCount,
    createdAt: u.createdAt,
  };
}

// The logged-in user's own view, including permissions and cooldowns.
export function privateProfile(u: ChatUser) {
  const nextNameChange = u.nameChangedAt ? new Date(u.nameChangedAt.getTime() + NAME_CHANGE_COOLDOWN_MS) : null;
  return {
    ...publicProfile(u),
    imagePerms: isVerified(u),
    hasPassword: !!u.passwordHash,
    newAccountUntil: isNewAccount(u) ? new Date(u.createdAt.getTime() + NEW_ACCOUNT_MS) : null,
    mutedUntil: isMuted(u) ? u.mutedUntil : null,
    dmFriendsOnly: u.dmFriendsOnly,
    rulesAccepted: !!u.rulesAcceptedAt,
    nextNameChangeAt: nextNameChange && nextNameChange.getTime() > Date.now() ? nextNameChange : null,
  };
}

const IMAGE_TYPES: Record<string, string> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/gif": "gif",
  "image/webp": "webp",
};

// Works out the real image type from the file's first bytes, ignoring whatever type the browser claimed.
export function sniffImageType(bytes: Uint8Array): string | null {
  const starts = (sig: number[], offset = 0) => sig.every((b, i) => bytes[offset + i] === b);
  if (starts([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) return "image/png";
  if (starts([0xff, 0xd8, 0xff])) return "image/jpeg";
  if (starts([0x47, 0x49, 0x46, 0x38]) && (bytes[4] === 0x37 || bytes[4] === 0x39) && bytes[5] === 0x61) return "image/gif";
  if (starts([0x52, 0x49, 0x46, 0x46]) && starts([0x57, 0x45, 0x42, 0x50], 8)) return "image/webp";
  return null;
}

// Saves an uploaded image to Blobs and returns its key, or an error message.
export async function saveImage(file: unknown, prefix: string, maxBytes: number): Promise<{ key: string } | { error: string }> {
  if (!(file instanceof File) || file.size === 0) return { error: "No image was uploaded." };
  if (file.size > maxBytes) return { error: `Images must be under ${Math.round(maxBytes / 1024 / 1024)} MB.` };
  const data = await file.arrayBuffer();
  const type = sniffImageType(new Uint8Array(data, 0, Math.min(16, data.byteLength)));
  if (!type) return { error: "Images must be PNG, JPG, GIF or WebP." };
  const key = `${prefix}-${newToken().slice(0, 24)}.${IMAGE_TYPES[type]}`;
  await mediaStore().set(key, data, { metadata: { contentType: type } });
  return { key };
}

// Cloudflare Turnstile check for signups. Skipped (and logged) until TURNSTILE_SECRET_KEY is set.
export async function verifyTurnstile(token: unknown, ip: string): Promise<boolean> {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) return true;
  if (typeof token !== "string" || !token || token.length > 2048) return false;
  try {
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body: new URLSearchParams({ secret, response: token, remoteip: ip }),
    });
    const data = (await res.json()) as { success?: boolean };
    return !!data.success;
  } catch (err) {
    console.error("Turnstile check failed:", err);
    return false;
  }
}

export const isOnline = (u: ChatUser) => !u.bannedAt && Date.now() - u.lastSeen.getTime() < 30_000;
export const notAllowed = (error: string, status = 403, code?: string) => Response.json(code ? { error, code } : { error }, { status });
