import { lt, sql } from "drizzle-orm";
import { db } from "../db/index.js";
import { rateLimits } from "../db/schema.js";

// Counts one hit against `key` in a fixed window. Returns whether the caller is still under `limit`
// and, when not, how many seconds until the window resets.
//   if (!(await hit(`report:${user.id}`, 10, 3600)).ok) return tooMany();
export async function hit(key: string, limit: number, windowSeconds: number): Promise<{ ok: boolean; retryAfter: number }> {
  const [row] = await db
    .insert(rateLimits)
    .values({ key, count: 1, resetAt: sql`now() + make_interval(secs => ${windowSeconds})` as unknown as Date })
    .onConflictDoUpdate({
      target: rateLimits.key,
      set: {
        count: sql`case when ${rateLimits.resetAt} <= now() then 1 else ${rateLimits.count} + 1 end`,
        resetAt: sql`case when ${rateLimits.resetAt} <= now() then now() + make_interval(secs => ${windowSeconds}) else ${rateLimits.resetAt} end`,
      },
    })
    .returning();
  const retryAfter = Math.max(1, Math.ceil((row.resetAt.getTime() - Date.now()) / 1000));
  return { ok: row.count <= limit, retryAfter };
}

// Undo the counter for a key (e.g. clear failed-login hits after a successful login).
export async function resetHits(key: string) {
  await db.delete(rateLimits).where(sql`${rateLimits.key} = ${key}`);
}

export async function pruneRateLimits() {
  await db.delete(rateLimits).where(lt(rateLimits.resetAt, sql`now()`));
}

export function tooMany(retryAfter: number, message = "You're doing that too often. Try again in a bit.") {
  return Response.json({ error: message }, { status: 429, headers: { "Retry-After": String(retryAfter) } });
}

// Best-effort client IP for rate limit keys.
export function clientIp(req: Request, context?: { ip?: string }) {
  return context?.ip || req.headers.get("x-nf-client-connection-ip") || req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
}
