import { and, eq, or, sql } from "drizzle-orm";
import { db } from "../db/index.js";
import { chatBlocks, chatFilters, chatModLog, chatResetCodes, chatSessions, chatSettings, chatUsers } from "../db/schema.js";
import {
  MAX_LEVEL,
  MAX_XP,
  XP_PER_LEVEL,
  type ChatUser,
  deleteMedia,
  hashToken,
  newToken,
  roleOf,
} from "./chatroom.js";

// ---------- room settings (owner switches) ----------
export type RoomSettings = { slowModeSeconds: number; lockSignups: boolean; lockPhotos: boolean };
const ROOM_DEFAULTS: RoomSettings = { slowModeSeconds: 0, lockSignups: false, lockPhotos: false };
export const SLOW_MODE_CHOICES = [0, 5, 10, 30, 60, 300];

let roomCache: { at: number; value: RoomSettings } | null = null;

export async function getRoomSettings(): Promise<RoomSettings> {
  if (roomCache && Date.now() - roomCache.at < 10_000) return roomCache.value;
  const rows = await db.select().from(chatSettings);
  const value = { ...ROOM_DEFAULTS };
  for (const r of rows) {
    if (r.key === "slowModeSeconds") value.slowModeSeconds = Number(r.value) || 0;
    if (r.key === "lockSignups") value.lockSignups = r.value === "true";
    if (r.key === "lockPhotos") value.lockPhotos = r.value === "true";
  }
  roomCache = { at: Date.now(), value };
  return value;
}

export async function setRoomSetting(key: keyof RoomSettings, value: string) {
  await db
    .insert(chatSettings)
    .values({ key, value })
    .onConflictDoUpdate({ target: chatSettings.key, set: { value, updatedAt: sql`now()` } });
  roomCache = null;
}

// ---------- word & link filter ----------
export type FilterRule = typeof chatFilters.$inferSelect;
let filterCache: { at: number; rules: FilterRule[] } | null = null;

export async function getFilters(): Promise<FilterRule[]> {
  if (filterCache && Date.now() - filterCache.at < 15_000) return filterCache.rules;
  const rules = await db.select().from(chatFilters).orderBy(chatFilters.kind, chatFilters.pattern);
  filterCache = { at: Date.now(), rules };
  return rules;
}
export const clearFilterCache = () => {
  filterCache = null;
};

const LEET: Record<string, string> = { "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", $: "s", "!": "i" };
const normalize = (text: string) =>
  text
    .normalize("NFKD")
    .replace(/[̀-ͯ​-‏⁠﻿]/g, "")
    .toLowerCase()
    .replace(/[013457@$!]/g, (c) => LEET[c] || c);
const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// Hostnames mentioned in the text, whether written as full links or bare domains.
function hostsIn(text: string) {
  const hosts: string[] = [];
  const re = /\b(?:https?:\/\/)?((?:[a-z0-9-]+\.)+[a-z]{2,})(?=[/:?#\s]|$)/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) hosts.push(m[1].toLowerCase().replace(/^www\./, ""));
  return hosts;
}

// Returns the rule that matched, or null if the text is clean.
export async function checkText(text: string): Promise<FilterRule | null> {
  if (!text) return null;
  const rules = await getFilters();
  if (!rules.length) return null;
  const plain = normalize(text);
  const squashed = plain.replace(/[^a-z]/g, "");
  const hosts = hostsIn(text);
  for (const rule of rules) {
    if (rule.kind === "link") {
      const p = rule.pattern;
      if (hosts.some((h) => h === p || h.endsWith("." + p))) return rule;
    } else {
      const word = normalize(rule.pattern);
      if (new RegExp(`(^|[^a-z])${escapeRe(word)}($|[^a-z])`).test(plain)) return rule;
      // Catch "b.a.d" / "b a d" spellings for longer words.
      const letters = word.replace(/[^a-z]/g, "");
      if (letters.length >= 4 && squashed.includes(letters)) return rule;
    }
  }
  return null;
}

// Cleans up a filter entry typed by staff: words are lowercased, links become a bare hostname.
export function cleanFilterPattern(kind: unknown, raw: unknown): { kind: "word" | "link"; pattern: string } | null {
  if ((kind !== "word" && kind !== "link") || typeof raw !== "string") return null;
  let pattern = raw.trim().toLowerCase();
  if (kind === "link") {
    pattern = pattern.replace(/^[a-z]+:\/\//, "").replace(/^www\./, "").split(/[/?#:\s]/)[0];
    if (!/^([a-z0-9-]+\.)+[a-z]{2,}$/.test(pattern)) return null;
  } else if (pattern.length < 2 || pattern.length > 40) return null;
  return { kind, pattern };
}

// ---------- mod log ----------
export async function logAction(actor: ChatUser, action: string, target?: ChatUser | null, details = "") {
  await db.insert(chatModLog).values({
    actorId: actor.id,
    actorName: actor.username,
    action,
    targetId: target?.id ?? null,
    targetName: target?.username ?? null,
    details: details.slice(0, 500),
  });
}

// ---------- blocks ----------
export async function blockedIdsFor(userId: number) {
  const rows = await db.select({ id: chatBlocks.blockedId }).from(chatBlocks).where(eq(chatBlocks.blockerId, userId));
  return rows.map((r) => r.id);
}

// True if either user has blocked the other.
export async function eitherBlocked(a: number, b: number) {
  const [row] = await db
    .select({ id: chatBlocks.blockerId })
    .from(chatBlocks)
    .where(or(and(eq(chatBlocks.blockerId, a), eq(chatBlocks.blockedId, b)), and(eq(chatBlocks.blockerId, b), eq(chatBlocks.blockedId, a))))
    .limit(1);
  return !!row;
}

// ---------- staff actions on a user ----------
export const KICK_MINUTES = 5;
export const TIMEOUT_CHOICES = [5, 10, 60, 1440, 10080];
export const MOD_ACTIONS = [
  "kick", "ban", "unban", "mod", "unmod", "verify", "unverify", "setLevel", "addXp",
  "timeout", "untimeout", "removeAvatar", "removeBanner", "resetCode",
] as const;
export type ModAction = (typeof MOD_ACTIONS)[number];

type ModResult = { user: ChatUser; code?: string } | { error: string; status: number };

// Who may act on whom: nobody touches the owner, and only the owner can act on mods or hand out the Mod role.
export function permissionError(actor: ChatUser, target: ChatUser, action: string): string | null {
  if (target.id === actor.id) return "You can't do that to yourself.";
  const actorRole = roleOf(actor);
  const targetRole = roleOf(target);
  if (actorRole === "member") return "Only the owner and mods can do that.";
  if (targetRole === "owner") return "Nobody can moderate the owner.";
  if ((action === "mod" || action === "unmod") && actorRole !== "owner") return "Only the owner can give or remove the Mod role.";
  if (targetRole === "mod" && actorRole !== "owner") return "Mods can't moderate other mods.";
  return null;
}

const CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
function newResetCode() {
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  const chars = Array.from(bytes, (b) => CODE_ALPHABET[b % CODE_ALPHABET.length]).join("");
  return `${chars.slice(0, 4)}-${chars.slice(4)}`;
}
export const normalizeResetCode = (raw: unknown) => (typeof raw === "string" ? raw.toUpperCase().replace(/[^A-Z0-9]/g, "") : "");
export const RESET_CODE_MINUTES = 60;

export async function applyModAction(actor: ChatUser, target: ChatUser, action: ModAction, extra: Record<string, unknown> = {}): Promise<ModResult> {
  const denied = permissionError(actor, target, action);
  if (denied) return { error: denied, status: 403 };

  let changes: Partial<typeof chatUsers.$inferInsert> = {};
  let endSessions = false;
  let details = "";
  let code: string | undefined;
  switch (action) {
    case "kick":
      changes = { kickedUntil: sql`now() + make_interval(mins => ${KICK_MINUTES})` as unknown as Date, typingAt: null };
      endSessions = true;
      details = `${KICK_MINUTES} minutes`;
      break;
    case "ban":
      // Banned users also lose the Mod role.
      changes = { bannedAt: sql`now()` as unknown as Date, role: "member", typingAt: null };
      endSessions = true;
      break;
    case "unban":
      changes = { bannedAt: null, kickedUntil: null };
      break;
    case "mod":
      if (target.bannedAt) return { error: "Unban them first.", status: 400 };
      changes = { role: "mod" };
      break;
    case "unmod":
      changes = { role: "member" };
      break;
    case "verify":
    case "unverify":
      changes = { imagePerms: action === "verify" };
      break;
    case "timeout": {
      const minutes = Number(extra.minutes);
      if (!TIMEOUT_CHOICES.includes(minutes)) return { error: "Pick a timeout length.", status: 400 };
      changes = { mutedUntil: sql`now() + make_interval(mins => ${minutes})` as unknown as Date, typingAt: null };
      details = minutes >= 1440 ? `${minutes / 1440} day${minutes === 1440 ? "" : "s"}` : minutes >= 60 ? `${minutes / 60} hour` : `${minutes} minutes`;
      break;
    }
    case "untimeout":
      changes = { mutedUntil: null };
      break;
    case "removeAvatar":
    case "removeBanner": {
      const column = action === "removeAvatar" ? "avatarKey" : "bannerKey";
      if (!target[column]) return { error: action === "removeAvatar" ? "They don't have a profile picture." : "They don't have a banner.", status: 400 };
      await deleteMedia([target[column]]);
      changes = { [column]: null };
      break;
    }
    case "resetCode": {
      if (target.bannedAt) return { error: "Unban them first.", status: 400 };
      code = newResetCode();
      // Only the newest code works.
      await db.delete(chatResetCodes).where(eq(chatResetCodes.userId, target.id));
      await db.insert(chatResetCodes).values({
        userId: target.id,
        codeHash: await hashToken(normalizeResetCode(code)),
        issuedById: actor.id,
        expiresAt: sql`now() + make_interval(mins => ${RESET_CODE_MINUTES})` as unknown as Date,
      });
      details = `valid for ${RESET_CODE_MINUTES} minutes`;
      break;
    }
    case "setLevel": {
      const level = Number(extra.level);
      if (!Number.isInteger(level) || level < 1 || level > MAX_LEVEL) return { error: `Pick a level from 1 to ${MAX_LEVEL}.`, status: 400 };
      changes = { xp: (level - 1) * XP_PER_LEVEL };
      details = `level ${level}`;
      break;
    }
    case "addXp": {
      const amount = Number(extra.amount);
      if (!Number.isInteger(amount) || amount < 1 || amount > MAX_XP) return { error: `Pick an amount of XP from 1 to ${MAX_XP}.`, status: 400 };
      changes = { xp: sql`least(${chatUsers.xp} + ${amount}, ${MAX_XP})` as unknown as number };
      details = `${amount} XP`;
      break;
    }
  }

  // Also rotate the legacy single-device token so old pre-session logins end too.
  if (endSessions) changes.tokenHash = await hashToken(newToken());
  let updated = target;
  if (Object.keys(changes).length) [updated] = await db.update(chatUsers).set(changes).where(eq(chatUsers.id, target.id)).returning();
  if (endSessions) await db.delete(chatSessions).where(eq(chatSessions.userId, target.id));
  if (typeof extra.reason === "string" && extra.reason) details = [details, extra.reason].filter(Boolean).join(" · ");
  await logAction(actor, action, target, details);
  return { user: updated, code };
}
