import { and, count, eq, inArray, sql } from "drizzle-orm";
import { db } from "../db/index.js";
import { chatReactions, chatReports, chatUsers } from "../db/schema.js";
import { type ChatUser, isStaff, roleOf } from "./chatroom.js";
import type { FilterRule } from "./moderation.js";

export type Reaction = { emoji: string; count: number; mine: boolean };

// A single emoji (including skin tones, flags and ZWJ sequences like 🧑‍💻).
const EMOJI_PATTERN = /^(?:\p{Extended_Pictographic}|\p{Emoji_Component}|\p{Regional_Indicator}|‍|️|⃣){1,12}$/u;
export function validEmoji(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const emoji = raw.trim();
  if (!emoji || emoji.length > 16 || !EMOJI_PATTERN.test(emoji) || /^[0-9#*]+$/.test(emoji)) return null;
  return emoji;
}
export const MAX_EMOJI_PER_MESSAGE = 20;

// Reactions on #general messages ("messageId") or DMs ("dmId"), grouped by emoji in the order they were first added.
export async function reactionsFor(column: "messageId" | "dmId", ids: number[], viewerId: number) {
  const out = new Map<number, Reaction[]>();
  if (!ids.length) return out;
  const col = chatReactions[column];
  const rows = await db
    .select({
      id: col,
      emoji: chatReactions.emoji,
      n: count(),
      mine: sql<boolean>`bool_or(${chatReactions.userId} = ${viewerId})`,
    })
    .from(chatReactions)
    .where(inArray(col, ids))
    .groupBy(col, chatReactions.emoji)
    .orderBy(sql`min(${chatReactions.id})`);
  for (const r of rows) {
    if (r.id == null) continue;
    const list = out.get(r.id) ?? [];
    list.push({ emoji: r.emoji, count: Number(r.n), mine: !!r.mine });
    out.set(r.id, list);
  }
  return out;
}

export const snippet = (text: string, max = 140) => (text.length > max ? text.slice(0, max - 1) + "…" : text);

// Files a mod-queue report on behalf of the word/link filter.
export async function flagFiltered(author: ChatUser, rule: FilterRule, where: { messageId?: number; dmId?: number }, text: string) {
  await db.insert(chatReports).values({
    reporterId: null,
    targetUserId: author.id,
    messageId: where.messageId ?? null,
    dmId: where.dmId ?? null,
    kind: "filter",
    reason: "filter",
    details: `Matched the ${rule.kind} filter: "${rule.pattern}"${where.dmId ? " (in a private message)" : ""}`,
    snapshot: snippet(text, 2000),
    againstStaff: isStaff(author),
  });
}

// Open reports this staff member can see. Reports against the owner or mods are for the owner only.
export async function openReportCount(viewer: ChatUser) {
  if (!isStaff(viewer)) return 0;
  const where = roleOf(viewer) === "owner"
    ? eq(chatReports.status, "open")
    : and(eq(chatReports.status, "open"), eq(chatReports.againstStaff, false));
  const [row] = await db.select({ n: count() }).from(chatReports).where(where);
  return Number(row?.n ?? 0);
}

export async function usersById(ids: number[]) {
  const unique = [...new Set(ids)];
  if (!unique.length) return new Map<number, ChatUser>();
  const rows = await db.select().from(chatUsers).where(inArray(chatUsers.id, unique));
  return new Map(rows.map((u) => [u.id, u]));
}

// Who may delete a message: its author, or staff (mods can't delete messages from the owner or other mods).
export function canDelete(actor: ChatUser, author: ChatUser) {
  if (actor.id === author.id) return true;
  const actorRole = roleOf(actor);
  const authorRole = roleOf(author);
  if (actorRole === "member" || authorRole === "owner") return false;
  return actorRole === "owner" || authorRole !== "mod";
}
