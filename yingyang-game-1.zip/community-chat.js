// ===== COMMUNITY CHAT =====
// Sign up / log in with a password → live #general room with typing indicators, emojis, photos & GIFs
// (Verified role only), levels and free "nitro" profile customisation.
(function () {
    const API = '/api/chatroom';
    const TOKEN_KEY = 'yyChatToken';
    const DISCORD_INVITE = 'https://discord.gg/AwfYXnYhdK';
    const NO_IMAGE_PERMS = 'Only Verified members can send photos and GIFs — join the discord to get verified, heres the invite ' + DISCORD_INVITE;
    const XP_PER_LEVEL = 250;
    const MAX_LEVEL = 100;
    const DECORATIONS = ['none', 'glow', 'rainbow', 'fire', 'ice', 'gold', 'neon', 'sakura'];
    // Animated overlays drawn over the whole profile card, like Discord's profile effects.
    const PROFILE_EFFECTS = {
        none: { icon: '🚫', label: 'None' },
        sparkles: { icon: '✨', label: 'Sparkles', particle: '✨', motion: 'twinkle' },
        snow: { icon: '❄️', label: 'Snow', particle: '❄', motion: 'fall' },
        hearts: { icon: '💖', label: 'Hearts', particle: '💖', motion: 'rise' },
        stars: { icon: '⭐', label: 'Stars', particle: '⭐', motion: 'twinkle' },
        sakura: { icon: '🌸', label: 'Sakura', particle: '🌸', motion: 'fall' },
        bubbles: { icon: '🫧', label: 'Bubbles', particle: '', motion: 'rise' },
        fire: { icon: '🔥', label: 'Fire', particle: '🔥', motion: 'rise' },
        confetti: { icon: '🎉', label: 'Confetti', particle: '', motion: 'fall' },
    };
    const NAME_EFFECTS = ['none', 'glow', 'neon', 'shimmer', 'rainbow', 'wave', 'pop'];
    const GROUP_WINDOW_MS = 5 * 60 * 1000;

    const $ = (id) => document.getElementById(id);
    const els = {
        login: $('ccLogin'), loginForm: $('ccLoginForm'), loginInput: $('ccLoginInput'), passwordInput: $('ccPasswordInput'), passwordConfirm: $('ccPasswordConfirm'),
        loginError: $('ccLoginError'), loginBtn: $('ccLoginBtn'), loginToggle: $('ccLoginModeToggle'),
        authTitle: $('ccAuthTitle'), authSub: $('ccAuthSub'), ownerBtn: $('ccOwnerLoginBtn'),
        chat: $('ccChat'), online: $('ccOnline'), me: $('ccMe'), messages: $('ccMessages'), list: $('ccMessageList'),
        historyStatus: $('ccHistoryStatus'), jump: $('ccJump'), typing: $('ccTyping'), input: $('ccInput'),
        sendBtn: $('ccSendBtn'), uploadBtn: $('ccUploadBtn'), fileInput: $('ccFileInput'), emojiBtn: $('ccEmojiBtn'),
        emojiPicker: $('ccEmojiPicker'), gifBtn: $('ccGifBtn'), composerError: $('ccComposerError'), imagePreview: $('ccImagePreview'),
        settings: $('ccSettings'), popout: $('ccPopout'), lightbox: $('ccLightbox'), fab: $('ccFab'), fabBadge: $('ccFabBadge'), toast: $('ccToast'),
        peopleBtn: $('ccPeopleBtn'), peopleBadge: $('ccPeopleBadge'), side: $('ccSide'), sideBody: $('ccSideBody'), sideClose: $('ccSideClose'),
        onlineCount: $('ccOnlineCount'), friendsBadge: $('ccFriendsBadge'), bannedTab: $('ccBannedTab'),
        dm: $('ccDm'), dmBack: $('ccDmBack'), dmWho: $('ccDmWho'), dmMessages: $('ccDmMessages'), dmStatus: $('ccDmStatus'), dmList: $('ccDmList'),
        dmError: $('ccDmError'), dmInput: $('ccDmInput'), dmSend: $('ccDmSend'),
    };

    let token = null;
    try { token = localStorage.getItem(TOKEN_KEY); } catch (e) {}
    let me = null;
    let lastId = 0;
    let oldestId = 0;
    let hasMore = true;
    let loadingOlder = false;
    let polling = false;
    let pollTimer = null;
    let lastTypingSent = 0;
    let pendingImage = null;
    let pendingGif = null;
    let unread = 0;
    let sending = false;
    const seen = new Set();
    let lastRendered = null; // newest rendered message, for grouping
    let firstRendered = null; // oldest rendered message

    // ---------- helpers ----------
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const isChatPage = () => $('page-chat').classList.contains('active');

    async function api(path, opts = {}) {
        const headers = Object.assign({}, opts.headers || {});
        if (token) headers.Authorization = 'Bearer ' + token;
        if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(opts.json); }
        const res = await fetch(API + path, { method: opts.method || 'GET', headers, body: opts.body });
        let data = {};
        try { data = await res.json(); } catch (e) {}
        if (res.status === 401 && token && !['/register', '/login', '/logout'].includes(path)) logout(true);
        return { ok: res.ok, status: res.status, data };
    }

    function showError(el, text) {
        if (!text) { el.classList.add('hidden'); el.textContent = ''; return; }
        // Turn the Discord invite (or any link) into a clickable link.
        el.innerHTML = esc(text).replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
        el.classList.remove('hidden');
    }

    let toastTimer;
    function toast(text) {
        els.toast.textContent = text;
        els.toast.classList.remove('hidden');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => els.toast.classList.add('hidden'), 3500);
    }

    function levelInfo(xp) {
        const level = Math.min(MAX_LEVEL, 1 + Math.floor(xp / XP_PER_LEVEL));
        const into = level >= MAX_LEVEL ? XP_PER_LEVEL : xp % XP_PER_LEVEL;
        return { level, into, pct: Math.round((into / XP_PER_LEVEL) * 100) };
    }

    function avatarColor(name) {
        let h = 0;
        for (const c of String(name)) h = (h * 31 + c.charCodeAt(0)) % 360;
        return `hsl(${h}, 55%, 45%)`;
    }

    function avatarHtml(u, size) {
        const cls = `cc-avatar ${size ? 'cc-' + size : ''} cc-deco-${esc(u.decoration || 'none')}`;
        const inner = u.avatar
            ? `<img class="cc-avatar-img" src="${esc(u.avatar)}" alt="">`
            : `<div class="cc-avatar-img" style="background:${avatarColor(u.username)}">${esc((u.username || '?').charAt(0).toUpperCase())}</div>`;
        return `<div class="${cls}" data-user="${u.id}">${inner}</div>`;
    }

    function nameHtml(u, clickable) {
        const font = u.nameFont && u.nameFont !== 'default' ? ' cc-font-' + esc(u.nameFont) : '';
        const fx = NAME_EFFECTS.includes(u.nameEffect) && u.nameEffect !== 'none' ? u.nameEffect : '';
        // Shimmer and rainbow paint the text with their own animated gradient.
        const paintsFill = fx === 'shimmer' || fx === 'rainbow';
        const c1 = esc(u.nameColor || '#fff');
        const c2 = esc(u.nameGradient || u.nameColor || '#fff');
        let style;
        if (paintsFill) style = `--cc-c1:${c1};--cc-c2:${c2}`;
        else if (u.nameGradient) style = `background-image:linear-gradient(90deg,${c1},${c2})`;
        else style = `color:${c1}`;
        const grad = u.nameGradient || paintsFill ? ' cc-grad' : '';
        return `<span class="cc-name${grad}${font}${fx ? ' cc-fx-' + fx : ''}${clickable ? ' cc-clickable' : ''}" style="${style}" data-user="${u.id}">${esc(u.username)}</span>`;
    }

    function profileEffectHtml(effect) {
        const fx = PROFILE_EFFECTS[effect];
        if (!fx || effect === 'none') return '';
        const confettiColors = ['#ff004c', '#ffb300', '#3cff00', '#00d0ff', '#a100ff', '#ff6ad5'];
        let parts = '';
        for (let i = 0; i < 14; i++) {
            const left = (i * 37 + 7) % 100;
            const delay = ((i * 0.61) % 4).toFixed(2);
            const dur = (3.5 + (i % 4) * 0.8).toFixed(1);
            const size = 10 + ((i * 7) % 9);
            const extra = effect === 'confetti' ? `background:${confettiColors[i % confettiColors.length]};` : '';
            parts += `<span style="left:${left}%;animation-delay:-${delay}s;animation-duration:${dur}s;font-size:${size}px;${extra}">${fx.particle}</span>`;
        }
        return `<div class="cc-pfx cc-pfx-${fx.motion} cc-pfx-${esc(effect)}" aria-hidden="true">${parts}</div>`;
    }

    // Owner (gold), Mod (red-gold) and Verified (green — given out by staff, unlocks photos & GIFs).
    const ROLES = { owner: { label: 'Owner', tag: 'OWNER' }, mod: { label: 'Mod', tag: 'MOD' } };
    const isStaff = (u) => !!u && (u.role === 'owner' || u.role === 'mod');
    function roleBadges(u) {
        const role = ROLES[u.role];
        return (u.verified ? `<span class="cc-verified" title="Verified">✔</span>` : '') +
            (role ? `<span class="cc-role cc-role-${u.role}" title="${role.label}">${role.tag}</span>` : '');
    }
    function rolePills(u) {
        let pills = u.verified ? `<span class="cc-role-pill cc-role-pill-verified"><i></i>Verified</span>` : '';
        if (u.role === 'mod') pills = `<span class="cc-role-pill cc-role-pill-mod"><i></i>🛡️ Mod</span>` + pills;
        if (u.role === 'owner') pills = `<span class="cc-role-pill cc-role-pill-owner"><i></i>👑 Owner</span>` + pills;
        if (u.banned) pills += `<span class="cc-role-pill cc-role-pill-banned"><i></i>Banned</span>`;
        return `<div class="cc-roles">${pills || '<span class="cc-role-pill"><i></i>Member</span>'}</div>`;
    }

    function levelBadge(level) {
        return `<span class="cc-lvl${level >= MAX_LEVEL ? ' cc-max' : ''}" title="Level ${level}">LV ${level}</span>`;
    }

    function formatTime(iso) {
        const d = new Date(iso);
        const time = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
        const today = new Date();
        const yesterday = new Date(); yesterday.setDate(today.getDate() - 1);
        if (d.toDateString() === today.toDateString()) return 'Today at ' + time;
        if (d.toDateString() === yesterday.toDateString()) return 'Yesterday at ' + time;
        return d.toLocaleDateString() + ' ' + time;
    }

    function formatContent(text) {
        let html = esc(text);
        html = html.replace(/`([^`\n]+)`/g, '<code>$1</code>');
        html = html.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
        html = html.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>');
        html = html.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
        html = html.replace(/(^|\s)@([A-Za-z0-9_.]{2,20})/g, '$1<span class="cc-at">@$2</span>');
        return html;
    }

    const emojiOnly = (t) => t && t.length <= 24 && /^(\p{Extended_Pictographic}|\p{Emoji_Component}|‍|️|\s)+$/u.test(t) && /\p{Extended_Pictographic}/u.test(t);

    // ---------- profile card ----------
    function profileCardHtml(u, actions) {
        const lvl = levelInfo(u.xp || 0);
        const banner = u.banner ? `background-image:url('${esc(u.banner)}');background-color:${esc(u.bannerColor)}` : `background:${esc(u.bannerColor)}`;
        const joined = u.createdAt ? new Date(u.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '';
        const status = u.statusEmoji || u.statusText ? `<div class="cc-status">${esc(u.statusEmoji)} ${esc(u.statusText)}</div>` : '';
        return `<div class="cc-card" style="background:linear-gradient(180deg,${esc(u.themePrimary)},${esc(u.themeAccent)})">
            ${profileEffectHtml(u.profileEffect)}
            <div class="cc-card-inner">
                <div class="cc-card-banner" style="${banner}"></div>
                <div class="cc-card-avatar">${avatarHtml(u, 'lg')}</div>
                <div class="cc-card-body">
                    <div class="cc-card-name">${nameHtml(u)}${roleBadges(u)}</div>
                    ${status}
                    <div class="cc-badges"><span class="cc-badge">💎 Nitro</span>${levelBadge(lvl.level)}<span class="cc-badge">💬 ${u.messageCount || 0} messages</span></div>
                    ${actions || ''}
                    <div class="cc-card-section"><h6>Roles</h6>${rolePills(u)}</div>
                    ${u.bio ? `<div class="cc-card-section"><h6>About me</h6>${esc(u.bio)}</div>` : ''}
                    <div class="cc-card-section"><h6>Level ${lvl.level}${lvl.level >= MAX_LEVEL ? ' · MAX' : ` / ${MAX_LEVEL}`}</h6>
                        <div class="cc-xpbar" style="width:100%"><div style="width:${lvl.pct}%"></div></div>
                        ${lvl.level >= MAX_LEVEL
                            ? '<span class="cc-xp-need">👑 Max level reached!</span>'
                            : `<span class="cc-xp-need"><b>${XP_PER_LEVEL - lvl.into} XP</b> needed to reach <b>level ${lvl.level + 1}</b></span>
                               <span class="cc-xptext">${lvl.into} / ${XP_PER_LEVEL} XP · about ${Math.ceil((XP_PER_LEVEL - lvl.into) / 5)} more messages · ${u.xp || 0} XP total</span>`}
                    </div>
                    ${joined ? `<div class="cc-card-section"><h6>Member since</h6>${esc(joined)}</div>` : ''}
                </div>
            </div>
        </div>`;
    }

    const knownUsers = new Map();
    // Friends, incoming and outgoing friend requests (refreshed by pollSocial).
    let social = { friends: [], incoming: [], outgoing: [] };
    function relation(userId) {
        if (social.friends.some((f) => f.id === userId)) return 'friends';
        if (social.incoming.some((f) => f.id === userId)) return 'incoming';
        if (social.outgoing.some((f) => f.id === userId)) return 'outgoing';
        return 'none';
    }
    // Owner & mods can kick/ban, verify and edit the level/XP of members; only the owner can moderate mods or hand out the Mod role.
    const canModerate = (u) => isStaff(me) && u.id !== me.id && u.role !== 'owner' && (me.role === 'owner' || u.role !== 'mod');

    function popoutActions(u) {
        if (!me || u.id === me.id) return '';
        const btn = (act, label, cls) => `<button type="button" class="cc-btn ${cls || ''}" data-act="${act}">${label}</button>`;
        let friendBtns = '';
        switch (relation(u.id)) {
            case 'friends': friendBtns = btn('dm', '💬 Message', 'cc-btn-primary') + btn('unfriend', 'Remove friend', 'cc-btn-ghost'); break;
            case 'incoming': friendBtns = btn('befriend', '✅ Accept friend', 'cc-btn-primary') + btn('unfriend', 'Decline', 'cc-btn-ghost'); break;
            case 'outgoing': friendBtns = `<span class="cc-hint">Friend request sent</span>` + btn('unfriend', 'Cancel', 'cc-btn-ghost'); break;
            default: friendBtns = btn('befriend', '➕ Add Friend', 'cc-btn-primary');
        }
        let mod = '';
        if (canModerate(u)) {
            if (u.banned) mod += btn('unban', 'Unban');
            else mod += btn('kick', '👢 Kick', 'cc-btn-danger') + btn('ban', '🔨 Ban', 'cc-btn-danger');
            if (me.role === 'owner' && !u.banned) mod += u.role === 'mod' ? btn('unmod', 'Remove Mod') : btn('mod', '🛡️ Make Mod', 'cc-btn-mod');
            // Staff are always Verified, so only members can be verified or unverified.
            if (u.role === 'member' && !u.banned) mod += u.verified ? btn('unverify', 'Remove Verified') : btn('verify', '✔ Verify', 'cc-btn-verify');
            mod += btn('setLevel', '📊 Set level') + btn('addXp', '✨ Add XP');
        }
        return `<div class="cc-card-actions">${friendBtns}</div>${mod ? `<div class="cc-card-actions cc-card-mod"><h6>Moderation</h6>${mod}</div>` : ''}`;
    }

    let popoutUser = null;
    function openPopout(userId, anchor) {
        const u = me && userId === me.id ? me : knownUsers.get(userId);
        if (!u) return;
        popoutUser = u.id;
        els.popout.innerHTML = profileCardHtml(u, popoutActions(u));
        els.popout.classList.remove('hidden');
        const r = anchor.getBoundingClientRect();
        const w = 300, h = els.popout.offsetHeight;
        let left = r.right + 10;
        if (left + w > window.innerWidth - 10) left = Math.max(10, r.left - w - 10);
        const top = Math.max(56, Math.min(r.top, window.innerHeight - h - 10));
        els.popout.style.left = left + 'px';
        els.popout.style.top = top + 'px';
    }
    const closePopout = () => { els.popout.classList.add('hidden'); popoutUser = null; };
    // Re-draw the open card in place (e.g. after adding a friend) without moving it.
    function refreshPopout() {
        if (popoutUser == null || els.popout.classList.contains('hidden')) return;
        const u = me && popoutUser === me.id ? me : knownUsers.get(popoutUser);
        if (u) els.popout.innerHTML = profileCardHtml(u, popoutActions(u));
    }

    const MOD_CONFIRM = {
        kick: (n) => `Kick ${n}? They'll be logged out and can't come back for 5 minutes.`,
        ban: (n) => `Ban ${n}? They won't be able to log in or chat until they're unbanned.`,
        mod: (n) => `Give ${n} the Mod role? Mods can kick and ban members.`,
        unmod: (n) => `Remove the Mod role from ${n}?`,
        unverify: (n) => `Remove the Verified role from ${n}? They won't be able to send photos or GIFs.`,
    };
    const MOD_DONE = {
        kick: '👢 Kicked', ban: '🔨 Banned', unban: '✅ Unbanned', mod: '🛡️ Mod role given to', unmod: 'Mod role removed from',
        verify: '✔ Verified', unverify: 'Verified role removed from',
    };
    // Asks for the new level / XP amount; returns the extra request fields or null if cancelled.
    function levelPrompt(u, action) {
        const ask = action === 'setLevel'
            ? `Set ${u.username}'s level (1–${MAX_LEVEL}). They're level ${u.level || levelInfo(u.xp || 0).level} now.`
            : `How much XP do you want to give ${u.username}? (${XP_PER_LEVEL} XP = 1 level)`;
        const raw = prompt(ask, action === 'setLevel' ? String(u.level || 1) : String(XP_PER_LEVEL));
        if (raw == null || !raw.trim()) return null;
        const n = Number(raw.trim());
        return action === 'setLevel' ? { level: n } : { amount: n };
    }

    async function moderate(u, action) {
        if (MOD_CONFIRM[action] && !confirm(MOD_CONFIRM[action](u.username))) return;
        let extra = {};
        if (action === 'setLevel' || action === 'addXp') {
            extra = levelPrompt(u, action);
            if (!extra) return;
        }
        const { ok, data } = await api('/moderate', { method: 'POST', json: { userId: u.id, action, ...extra } });
        if (!ok) { toast(data.error || 'That did not work.'); return; }
        knownUsers.set(data.user.id, Object.assign({}, knownUsers.get(data.user.id), data.user));
        onlineUsers = onlineUsers.map((x) => (x.id === data.user.id ? Object.assign({}, x, data.user) : x));
        if (action === 'setLevel') toast(`📊 ${data.user.username} is now level ${data.user.level}`);
        else if (action === 'addXp') toast(`✨ Gave ${data.user.username} ${extra.amount} XP — now level ${data.user.level}`);
        else toast(`${MOD_DONE[action]} ${data.user.username}`);
        if (action === 'kick' || action === 'ban') onlineUsers = onlineUsers.filter((x) => x.id !== u.id);
        if (sideTab === 'banned') loadBanned();
        else renderSide();
        refreshPopout();
    }

    async function friendAction(userId, add) {
        const { ok, data } = await api('/friends', { method: add ? 'POST' : 'DELETE', json: { userId } });
        if (!ok) { toast(data.error || 'That did not work.'); return; }
        if (data.status === 'friends') toast('🤝 You are now friends!');
        else if (data.status === 'outgoing') toast('📨 Friend request sent');
        await pollSocial();
        refreshPopout();
    }

    els.popout.addEventListener('click', (e) => {
        const b = e.target.closest('[data-act]');
        if (!b || popoutUser == null) return;
        const u = knownUsers.get(popoutUser);
        if (!u) return;
        const act = b.dataset.act;
        if (act === 'dm') { closePopout(); openDm(u.id); }
        else if (act === 'befriend') friendAction(u.id, true);
        else if (act === 'unfriend') friendAction(u.id, false);
        else moderate(u, act);
    });

    document.addEventListener('click', (e) => {
        const dmBtn = e.target.closest('[data-dm]');
        if (dmBtn && els.side.contains(dmBtn)) { e.stopPropagation(); openDm(Number(dmBtn.dataset.dm)); return; }
        const fBtn = e.target.closest('[data-friend]');
        if (fBtn && els.side.contains(fBtn)) { e.stopPropagation(); friendAction(Number(fBtn.dataset.id), fBtn.dataset.friend === 'accept'); return; }
        const target = e.target.closest('[data-user]');
        if (target && [els.list, els.me, els.sideBody, els.dmList, els.dmWho].some((c) => c.contains(target))) {
            e.stopPropagation();
            openPopout(Number(target.dataset.user), target);
            return;
        }
        if (!els.popout.contains(e.target)) closePopout();
        if (!els.emojiPicker.contains(e.target) && e.target !== els.emojiBtn) els.emojiPicker.classList.add('hidden');
    });

    // ---------- rendering ----------
    function renderMe() {
        if (!me) return;
        const lvl = levelInfo(me.xp);
        els.me.innerHTML = `${avatarHtml(me, 'sm')}<div class="cc-me-info">${nameHtml(me)}
            <div class="cc-xpbar"><div style="width:${lvl.pct}%"></div></div>
            <span class="cc-xptext">LV ${lvl.level}${lvl.level >= MAX_LEVEL ? ' · MAX' : ` · ${lvl.into}/${XP_PER_LEVEL} XP`}</span></div>`;
    }

    function sameGroup(prev, msg) {
        // OWNER / MOD tags show on every message staff send, so their messages never collapse.
        return prev && prev.author.id === msg.author.id && !isStaff(msg.author) &&
            new Date(msg.createdAt) - new Date(prev.createdAt) < GROUP_WINDOW_MS &&
            new Date(msg.createdAt).toDateString() === new Date(prev.createdAt).toDateString();
    }

    function dayDivider(msg) {
        const div = document.createElement('div');
        div.className = 'cc-day';
        div.textContent = new Date(msg.createdAt).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
        return div;
    }

    function messageEl(msg, prev) {
        knownUsers.set(msg.author.id, msg.author);
        const own = me && msg.author.id === me.id;
        const cont = sameGroup(prev, msg);
        const el = document.createElement('div');
        el.className = 'cc-msg' + (own ? ' cc-own' : '') + (cont ? ' cc-cont' : '');
        el.dataset.id = msg.id;
        const mention = !own && me && new RegExp('(^|\\s)@' + me.username.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i').test(msg.content);
        const text = msg.content
            ? `<div class="cc-bubble${emojiOnly(msg.content) ? ' cc-jumbo' : ''}${mention ? ' cc-mention' : ''}">${formatContent(msg.content)}</div>` : '';
        const img = (msg.image ? `<img class="cc-msg-img" src="${esc(msg.image)}" alt="Shared photo" loading="lazy">` : '') +
            (msg.gif ? `<img class="cc-msg-img cc-msg-gif" src="${esc(msg.gif)}" alt="GIF" loading="lazy" referrerpolicy="no-referrer">` : '');
        const head = cont ? '' : `<div class="cc-msg-head">${nameHtml(msg.author, true)}${roleBadges(msg.author)}${levelBadge(msg.author.level)}<span class="cc-time">${esc(formatTime(msg.createdAt))}</span></div>`;
        el.innerHTML = `<div class="cc-msg-gutter">${cont ? '' : avatarHtml(msg.author)}</div>
            <div class="cc-msg-body" title="${esc(formatTime(msg.createdAt))}">${head}${text}${img}</div>`;
        el.querySelectorAll('.cc-msg-img').forEach((imgEl) => imgEl.addEventListener('load', () => { if (nearBottom(400)) scrollToBottom(); }));
        return el;
    }

    const nearBottom = (px = 120) => els.messages.scrollHeight - els.messages.scrollTop - els.messages.clientHeight < px;
    const scrollToBottom = () => { els.messages.scrollTop = els.messages.scrollHeight; els.jump.classList.add('hidden'); };

    function appendMessages(msgs, forceScroll) {
        const fresh = msgs.filter((m) => !seen.has(m.id));
        if (!fresh.length) return 0;
        const stick = forceScroll || nearBottom();
        let othersCount = 0;
        fresh.forEach((m) => {
            seen.add(m.id);
            if (!lastRendered || new Date(m.createdAt).toDateString() !== new Date(lastRendered.createdAt).toDateString()) {
                els.list.appendChild(dayDivider(m));
            }
            els.list.appendChild(messageEl(m, lastRendered));
            lastRendered = m;
            if (!firstRendered) firstRendered = m;
            lastId = Math.max(lastId, m.id);
            if (!oldestId || m.id < oldestId) oldestId = m.id;
            if (!me || m.author.id !== me.id) othersCount++;
        });
        if (stick) scrollToBottom();
        else if (othersCount) els.jump.classList.remove('hidden');
        return othersCount;
    }

    function prependMessages(msgs) {
        const fresh = msgs.filter((m) => !seen.has(m.id));
        if (!fresh.length) return;
        const before = els.messages.scrollHeight;
        const frag = document.createDocumentFragment();
        let prev = null;
        fresh.forEach((m) => {
            seen.add(m.id);
            if (!prev || new Date(m.createdAt).toDateString() !== new Date(prev.createdAt).toDateString()) frag.appendChild(dayDivider(m));
            frag.appendChild(messageEl(m, prev));
            prev = m;
            if (!oldestId || m.id < oldestId) oldestId = m.id;
        });
        // The day divider at the top of the existing list is redundant if the day matches.
        const firstChild = els.list.firstElementChild;
        if (firstRendered && prev && firstChild && firstChild.classList.contains('cc-day') &&
            new Date(prev.createdAt).toDateString() === new Date(firstRendered.createdAt).toDateString()) firstChild.remove();
        els.list.insertBefore(frag, els.list.firstChild);
        firstRendered = fresh[0];
        els.messages.scrollTop += els.messages.scrollHeight - before;
    }

    function renderHistoryStatus() {
        els.historyStatus.innerHTML = hasMore
            ? (loadingOlder ? 'Loading older messages…' : '')
            : '<h3>Welcome to #general!</h3>This is the start of the chat. Say hi 👋';
    }

    function renderTyping(names) {
        if (!names.length) { els.typing.innerHTML = ''; return; }
        let text;
        if (names.length === 1) text = `<b>${esc(names[0])}</b> is typing…`;
        else if (names.length === 2) text = `<b>${esc(names[0])}</b> and <b>${esc(names[1])}</b> are typing…`;
        else if (names.length === 3) text = `<b>${esc(names[0])}</b>, <b>${esc(names[1])}</b> and <b>${esc(names[2])}</b> are typing…`;
        else text = 'Several people are typing…';
        els.typing.innerHTML = `<span class="cc-dots"><span></span><span></span><span></span></span><span>${text}</span>`;
    }

    function setMe(next) {
        const prevLevel = me ? levelInfo(me.xp).level : null;
        const prevRole = me ? me.role : null;
        me = next;
        if (prevRole && prevRole !== me.role) {
            toast(me.role === 'mod' ? '🛡️ The owner made you a Mod! You can now kick and ban.' : me.role === 'member' ? 'Your Mod role was removed.' : '👑 Owner');
            renderSide();
        }
        knownUsers.set(me.id, me);
        renderMe();
        const lvl = levelInfo(me.xp).level;
        if (prevLevel && lvl > prevLevel) toast(lvl >= MAX_LEVEL ? `👑 MAX LEVEL! You reached level ${MAX_LEVEL}!` : `🎉 Level up! You're now level ${lvl}`);
    }

    // ---------- online list, friends & banned ----------
    let onlineUsers = [];
    let bannedUsers = [];
    let sideTab = 'online';
    let sideOpen = window.matchMedia('(min-width: 1000px)').matches;
    let lastSocialAt = 0;
    let lastSocialPrimed = false; // skip "new message" toasts on the first load
    const dmUnreadTotal = () => social.friends.reduce((n, f) => n + (f.unread || 0), 0);

    function personRow(u, extra) {
        knownUsers.set(u.id, Object.assign({}, knownUsers.get(u.id), u));
        const status = u.statusEmoji || u.statusText ? `<span class="cc-person-status">${esc(u.statusEmoji)} ${esc(u.statusText)}</span>` : '';
        const dot = u.online === undefined ? '' : `<i class="cc-dot${u.online ? ' on' : ''}" title="${u.online ? 'Online' : 'Offline'}"></i>`;
        return `<div class="cc-person" data-user="${u.id}">
            <div class="cc-person-avatar">${avatarHtml(u, 'sm')}${dot}</div>
            <div class="cc-person-info"><div class="cc-person-name">${nameHtml(u)}${roleBadges(u)}</div>${status}</div>
            ${extra || ''}
        </div>`;
    }

    function renderSide() {
        if (!me) return;
        els.onlineCount.textContent = onlineUsers.length;
        const requests = social.incoming.length;
        const pending = dmUnreadTotal() + requests;
        els.friendsBadge.textContent = pending > 99 ? '99+' : String(pending);
        els.friendsBadge.classList.toggle('hidden', !pending);
        els.peopleBadge.textContent = els.friendsBadge.textContent;
        els.peopleBadge.classList.toggle('hidden', !pending);
        els.bannedTab.classList.toggle('hidden', !isStaff(me));
        if (sideTab === 'banned' && !isStaff(me)) sideTab = 'online';
        document.querySelectorAll('.cc-side-tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === sideTab));
        updateBadge();

        let html = '';
        if (sideTab === 'online') {
            const groups = [['owner', '👑 Owner'], ['mod', '🛡️ Mods'], ['verified', '✔ Verified'], ['member', '👥 Members']];
            const groupOf = (u) => (u.role === 'owner' || u.role === 'mod' ? u.role : u.verified ? 'verified' : 'member');
            for (const [role, label] of groups) {
                const list = onlineUsers.filter((u) => groupOf(u) === role);
                if (list.length) html += `<h5>${label} — ${list.length}</h5>` + list.map((u) => personRow(u)).join('');
            }
            if (!html) html = '<p class="cc-side-empty">Nobody else is here right now.</p>';
        } else if (sideTab === 'friends') {
            if (social.incoming.length) {
                html += `<h5>Friend requests — ${social.incoming.length}</h5>` + social.incoming.map((u) => personRow(u,
                    `<button class="cc-mini-btn cc-mini-ok" data-friend="accept" data-id="${u.id}" title="Accept">✓</button><button class="cc-mini-btn" data-friend="decline" data-id="${u.id}" title="Decline">✕</button>`)).join('');
            }
            html += `<h5>Friends — ${social.friends.length}</h5>`;
            html += social.friends.length
                ? social.friends.map((u) => personRow(u,
                    `${u.unread ? `<span class="cc-count-badge">${u.unread > 99 ? '99+' : u.unread}</span>` : ''}<button class="cc-mini-btn" data-dm="${u.id}" title="Message">💬</button>`)).join('')
                : '<p class="cc-side-empty">No friends yet — click someone\'s name and hit “Add Friend”.</p>';
            if (social.outgoing.length) {
                html += `<h5>Pending — ${social.outgoing.length}</h5>` + social.outgoing.map((u) => personRow(u,
                    `<button class="cc-mini-btn" data-friend="cancel" data-id="${u.id}" title="Cancel request">✕</button>`)).join('');
            }
        } else {
            html = bannedUsers.length
                ? `<h5>Banned — ${bannedUsers.length}</h5>` + bannedUsers.map((u) => personRow(u)).join('') + '<p class="cc-side-empty">Click someone to unban them.</p>'
                : '<p class="cc-side-empty">Nobody is banned.</p>';
        }
        // Skip identical re-renders so a click on a row isn't swallowed by the 2s poll.
        if (html !== lastSideHtml) els.sideBody.innerHTML = lastSideHtml = html;
    }
    let lastSideHtml = '';

    async function loadBanned() {
        const { ok, data } = await api('/moderate');
        if (ok) bannedUsers = data.banned || [];
        renderSide();
    }

    async function pollSocial() {
        if (!token || !me) return;
        lastSocialAt = Date.now();
        const before = new Map(social.friends.map((f) => [f.id, f.unread || 0]));
        const prevIncoming = new Set(social.incoming.map((u) => u.id));
        const { ok, data } = await api('/friends');
        if (!ok) return;
        social = { friends: data.friends || [], incoming: data.incoming || [], outgoing: data.outgoing || [] };
        // Let people know about new private messages and friend requests.
        social.friends.forEach((f) => {
            if (lastSocialPrimed && f.unread > (before.get(f.id) || 0) && dm.userId !== f.id) toast(`💬 New message from ${f.username}`);
        });
        if (lastSocialPrimed) social.incoming.forEach((u) => { if (!prevIncoming.has(u.id)) toast(`📨 ${u.username} sent you a friend request`); });
        lastSocialPrimed = true;
        renderSide();
    }

    function setSideOpen(open) {
        sideOpen = open;
        els.side.classList.toggle('hidden', !open || !me || els.chat.classList.contains('hidden'));
        els.peopleBtn.classList.toggle('active', open);
        if (open) renderSide();
    }
    els.peopleBtn.addEventListener('click', () => setSideOpen(!sideOpen));
    els.sideClose.addEventListener('click', () => setSideOpen(false));
    document.querySelectorAll('.cc-side-tab').forEach((t) => t.addEventListener('click', () => {
        sideTab = t.dataset.tab;
        if (sideTab === 'banned') loadBanned();
        else renderSide();
    }));

    // ---------- private messages ----------
    const dm = { userId: null, user: null, lastId: 0, oldestId: 0, hasMore: false, last: null, first: null, seen: new Set(), loading: false, sending: false };

    function dmAsMessage(m) {
        return { id: m.id, content: m.content, image: null, createdAt: m.createdAt, author: m.senderId === me.id ? me : dm.user };
    }

    function renderDmHeader() {
        const u = dm.user;
        if (!u) { els.dmWho.innerHTML = ''; return; }
        els.dmWho.innerHTML = `<span class="cc-at-sign">@</span><span class="cc-clickable-wrap" data-user="${u.id}">${nameHtml(u)}</span>${roleBadges(u)}
            <span class="cc-online${u.online ? '' : ' cc-offline'}"><i></i>${u.online ? 'Online' : 'Offline'}</span>`;
        els.dmInput.placeholder = `Message @${u.username}`;
    }

    function renderDmStatus(friends) {
        if (friends === false) { els.dmStatus.innerHTML = '<h3>You\'re not friends anymore</h3>Add each other as friends again to keep chatting.'; return; }
        els.dmStatus.innerHTML = dm.hasMore ? (dm.loading ? 'Loading older messages…' : '')
            : `<h3>@${esc(dm.user ? dm.user.username : '')}</h3>This is the start of your private conversation. Only you two can see it.`;
    }

    function appendDm(rows, force) {
        const stick = force || els.dmMessages.scrollHeight - els.dmMessages.scrollTop - els.dmMessages.clientHeight < 120;
        rows.filter((m) => !dm.seen.has(m.id)).forEach((raw) => {
            const m = dmAsMessage(raw);
            dm.seen.add(m.id);
            if (!dm.last || new Date(m.createdAt).toDateString() !== new Date(dm.last.createdAt).toDateString()) els.dmList.appendChild(dayDivider(m));
            els.dmList.appendChild(messageEl(m, dm.last));
            dm.last = m;
            if (!dm.first) dm.first = m;
            dm.lastId = Math.max(dm.lastId, m.id);
            if (!dm.oldestId || m.id < dm.oldestId) dm.oldestId = m.id;
        });
        if (stick) els.dmMessages.scrollTop = els.dmMessages.scrollHeight;
    }

    function prependDm(rows) {
        const fresh = rows.filter((m) => !dm.seen.has(m.id)).map(dmAsMessage);
        if (!fresh.length) return;
        const before = els.dmMessages.scrollHeight;
        const frag = document.createDocumentFragment();
        let prev = null;
        fresh.forEach((m) => {
            dm.seen.add(m.id);
            if (!prev || new Date(m.createdAt).toDateString() !== new Date(prev.createdAt).toDateString()) frag.appendChild(dayDivider(m));
            frag.appendChild(messageEl(m, prev));
            prev = m;
            if (!dm.oldestId || m.id < dm.oldestId) dm.oldestId = m.id;
        });
        const firstChild = els.dmList.firstElementChild;
        if (dm.first && prev && firstChild && firstChild.classList.contains('cc-day') &&
            new Date(prev.createdAt).toDateString() === new Date(dm.first.createdAt).toDateString()) firstChild.remove();
        els.dmList.insertBefore(frag, els.dmList.firstChild);
        dm.first = fresh[0];
        els.dmMessages.scrollTop += els.dmMessages.scrollHeight - before;
    }

    function applyDmData(data) {
        dm.user = Object.assign({}, knownUsers.get(data.user.id), data.user);
        knownUsers.set(dm.user.id, dm.user);
        renderDmHeader();
        const canSend = data.friends;
        els.dmInput.disabled = !canSend;
        els.dmSend.disabled = !canSend;
        renderDmStatus(canSend ? undefined : false);
    }

    async function openDm(userId) {
        if (!me) return;
        closePopout();
        if (!window.matchMedia('(min-width: 1000px)').matches) setSideOpen(false);
        Object.assign(dm, { userId, user: knownUsers.get(userId) || null, lastId: 0, oldestId: 0, hasMore: false, last: null, first: null, loading: false });
        dm.seen.clear();
        els.dmList.innerHTML = '';
        showError(els.dmError, '');
        els.dmInput.value = '';
        els.dm.classList.remove('hidden');
        renderDmHeader();
        const { ok, data } = await api('/dms?with=' + userId);
        if (!ok || dm.userId !== userId) { if (!ok) showError(els.dmError, data.error || 'Could not open this conversation.'); return; }
        dm.hasMore = data.hasMore;
        applyDmData(data);
        appendDm(data.messages, true);
        if (data.friends) renderDmStatus();
        if (window.matchMedia('(min-width: 641px)').matches) els.dmInput.focus();
        pollSocial();
    }

    function closeDm() {
        dm.userId = null;
        dm.user = null;
        els.dm.classList.add('hidden');
    }
    els.dmBack.addEventListener('click', closeDm);

    let dmPolling = false;
    async function pollDm() {
        if (dmPolling || dm.userId == null) return;
        dmPolling = true;
        const userId = dm.userId;
        try {
            const { ok, data } = await api('/dms?with=' + userId + (dm.lastId ? '&after=' + dm.lastId : ''));
            if (!ok || dm.userId !== userId) return;
            applyDmData(data);
            appendDm(data.messages);
            if (data.friends) renderDmStatus();
        } catch (e) {
        } finally {
            dmPolling = false;
        }
    }

    els.dmMessages.addEventListener('scroll', async () => {
        if (els.dmMessages.scrollTop > 120 || !dm.hasMore || dm.loading || !dm.oldestId) return;
        const userId = dm.userId;
        dm.loading = true;
        renderDmStatus();
        try {
            const { ok, data } = await api('/dms?with=' + userId + '&before=' + dm.oldestId);
            if (ok && dm.userId === userId) { dm.hasMore = data.hasMore; prependDm(data.messages); }
        } finally {
            dm.loading = false;
            renderDmStatus();
        }
    });

    function dmAutosize() {
        els.dmInput.style.height = 'auto';
        els.dmInput.style.height = Math.min(160, els.dmInput.scrollHeight) + 'px';
    }
    async function sendDm() {
        const content = els.dmInput.value.trim();
        if (!content || dm.sending || dm.userId == null) return;
        dm.sending = true;
        els.dmSend.disabled = true;
        try {
            const { ok, data } = await api('/dms', { method: 'POST', json: { to: dm.userId, content } });
            if (!ok) { showError(els.dmError, data.error || 'Message failed to send.'); return; }
            els.dmInput.value = '';
            dmAutosize();
            appendDm([data.message], true);
        } catch (e) {
            showError(els.dmError, 'Message failed to send — check your connection.');
        } finally {
            dm.sending = false;
            els.dmSend.disabled = false;
            els.dmInput.focus();
        }
    }
    els.dmInput.addEventListener('input', () => { dmAutosize(); showError(els.dmError, ''); });
    els.dmInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendDm(); }
    });
    els.dmSend.addEventListener('click', sendDm);

    // ---------- views ----------
    function showLogin() {
        els.chat.classList.add('hidden');
        els.side.classList.add('hidden');
        closeDm();
        els.login.classList.remove('hidden');
        stopPolling();
    }

    function resetRoom() {
        els.list.innerHTML = '';
        seen.clear();
        knownUsers.clear();
        social = { friends: [], incoming: [], outgoing: [] };
        onlineUsers = []; bannedUsers = []; sideTab = 'online'; lastSocialAt = 0; lastSocialPrimed = false; lastSideHtml = '';
        closeDm();
        lastId = 0; oldestId = 0; hasMore = true; lastRendered = null; firstRendered = null; unread = 0;
        updateBadge();
    }

    async function enterChat() {
        els.login.classList.add('hidden');
        els.chat.classList.remove('hidden');
        setSideOpen(sideOpen);
        renderMe();
        if (!lastId) {
            const { ok, data } = await api('/messages');
            if (!ok) return;
            hasMore = data.hasMore;
            appendMessages(data.messages, true);
            applyPoll(data);
            renderHistoryStatus();
        }
        startPolling();
        if (!lastSocialAt) pollSocial();
        scrollToBottom();
        if (window.matchMedia('(min-width: 641px)').matches) els.input.focus();
    }

    function logout(expired) {
        if (!expired && token) api('/logout', { method: 'POST' }).catch(() => {});
        token = null;
        me = null;
        try { localStorage.removeItem(TOKEN_KEY); } catch (e) {}
        resetRoom();
        els.settings.classList.add('hidden');
        showLogin();
        if (expired) showError(els.loginError, 'Your session ended — please log in again.');
    }

    // ---------- log in / sign up ----------
    let authMode = 'login';
    function setAuthMode(mode) {
        authMode = mode;
        const signup = mode === 'signup';
        const owner = mode === 'owner';
        els.loginForm.classList.toggle('cc-owner-mode', owner);
        els.ownerBtn.classList.toggle('on', owner);
        els.ownerBtn.setAttribute('aria-pressed', String(owner));
        document.querySelectorAll('.cc-auth-tab').forEach((t) => t.classList.toggle('active', t.dataset.auth === mode));
        document.querySelectorAll('.cc-signup-only').forEach((el) => el.classList.toggle('hidden', !signup));
        els.authTitle.textContent = owner ? '👑 Owner Login' : signup ? 'Create an account' : 'Welcome back!';
        els.authSub.textContent = owner ? 'Owner access only.' : signup ? 'Pick a username and password to join the chat.' : 'Log in to start chatting with everyone online.';
        els.loginBtn.textContent = owner ? 'Owner Log In' : signup ? 'Sign Up' : 'Log In';
        els.loginToggle.textContent = signup ? 'Already have an account? Log in' : 'Need an account? Sign up';
        els.passwordInput.placeholder = signup ? 'Choose a password' : 'Your password';
        els.passwordInput.autocomplete = signup ? 'new-password' : 'current-password';
        showError(els.loginError, '');
    }
    document.querySelectorAll('.cc-auth-tab').forEach((t) => t.addEventListener('click', () => setAuthMode(t.dataset.auth)));
    els.loginToggle.addEventListener('click', () => setAuthMode(authMode === 'login' ? 'signup' : 'login'));
    // Secret crown in the corner of the login card opens the owner login (click again to go back).
    els.ownerBtn.addEventListener('click', () => {
        setAuthMode(authMode === 'owner' ? 'login' : 'owner');
        els.loginInput.focus();
    });

    // Eye buttons that show/hide a password field.
    document.querySelectorAll('.cc-pass-toggle').forEach((btn) => btn.addEventListener('click', () => {
        const input = $(btn.dataset.target);
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        btn.classList.toggle('on', show);
        btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    }));

    els.loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        showError(els.loginError, '');
        const username = els.loginInput.value.trim();
        const password = els.passwordInput.value;
        if (!username || !password) { showError(els.loginError, 'Please enter your username and password.'); return; }
        if (authMode === 'signup') {
            if (password.length < 6) { showError(els.loginError, 'Passwords must be at least 6 characters.'); return; }
            if (password !== els.passwordConfirm.value) { showError(els.loginError, "Passwords don't match."); return; }
        }
        els.loginBtn.disabled = true;
        try {
            const { ok, data } = await api(authMode === 'signup' ? '/register' : '/login', { method: 'POST', json: { username, password } });
            if (!ok) { showError(els.loginError, data.error || 'Something went wrong, try again.'); return; }
            token = data.token;
            try { localStorage.setItem(TOKEN_KEY, token); } catch (err) {}
            resetRoom();
            setMe(data.user);
            els.loginInput.value = '';
            els.passwordInput.value = '';
            els.passwordConfirm.value = '';
            const wasOwnerLogin = authMode === 'owner';
            if (wasOwnerLogin) setAuthMode('login');
            await enterChat();
            if (wasOwnerLogin && data.user.role === 'owner') toast(`👑 Welcome back, ${data.user.username}!`);
            if (authMode === 'signup') toast(`👋 Welcome to the chat, ${data.user.username}!`);
        } catch (err) {
            showError(els.loginError, 'Could not reach the chat server. Try again.');
        } finally {
            els.loginBtn.disabled = false;
        }
    });

    // ---------- polling ----------
    function applyPoll(data) {
        if (data.me) setMe(data.me);
        renderTyping(data.typing || []);
        els.online.innerHTML = `<i></i>${data.online || 0} online`;
        if (data.onlineUsers) {
            onlineUsers = data.onlineUsers;
            if (sideTab === 'online' && !els.side.classList.contains('hidden')) renderSide();
            else els.onlineCount.textContent = onlineUsers.length;
        }
    }

    async function poll() {
        if (polling || !token || !me) return;
        polling = true;
        try {
            const hadHistory = lastId > 0;
            const { ok, data } = await api('/messages' + (hadHistory ? '?after=' + lastId : ''));
            if (!ok) return;
            if (!hadHistory) { hasMore = data.hasMore; renderHistoryStatus(); }
            const others = appendMessages(data.messages);
            applyPoll(data);
            // Only messages that arrive after the first load count as unread.
            if (hadHistory && !isChatPage() && others) { unread += others; updateBadge(); }
        } catch (e) {
        } finally {
            polling = false;
        }
    }

    function startPolling() {
        stopPolling();
        const tick = () => {
            if (!document.hidden) {
                poll();
                if (dm.userId != null && isChatPage()) pollDm();
                // Friends & DM notifications: every 5s in the chat, every 15s elsewhere (same as the main poll).
                if (Date.now() - lastSocialAt > (isChatPage() ? 5000 : 14000)) pollSocial();
            }
            pollTimer = setTimeout(tick, isChatPage() ? 2000 : 15000);
        };
        pollTimer = setTimeout(tick, 2000);
    }
    function stopPolling() { clearTimeout(pollTimer); pollTimer = null; }
    document.addEventListener('visibilitychange', () => { if (!document.hidden && isChatPage()) poll(); });

    // Scroll up for history
    els.messages.addEventListener('scroll', async () => {
        if (nearBottom()) els.jump.classList.add('hidden');
        if (els.messages.scrollTop > 120 || !hasMore || loadingOlder || !oldestId) return;
        loadingOlder = true;
        renderHistoryStatus();
        try {
            const { ok, data } = await api('/messages?before=' + oldestId);
            if (ok) { hasMore = data.hasMore; prependMessages(data.messages); }
        } finally {
            loadingOlder = false;
            renderHistoryStatus();
        }
    });
    els.jump.addEventListener('click', scrollToBottom);

    // ---------- composer ----------
    function autosize() {
        els.input.style.height = 'auto';
        els.input.style.height = Math.min(160, els.input.scrollHeight) + 'px';
    }

    function sendTyping(typing) {
        if (!token) return;
        api('/typing', { method: 'POST', json: { typing } }).catch(() => {});
    }

    els.input.addEventListener('input', () => {
        autosize();
        showError(els.composerError, '');
        const now = Date.now();
        if (els.input.value.trim() && now - lastTypingSent > 3000) { lastTypingSent = now; sendTyping(true); }
        if (!els.input.value.trim() && lastTypingSent) { lastTypingSent = 0; sendTyping(false); }
    });
    els.input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); }
    });
    els.sendBtn.addEventListener('click', send);

    async function send() {
        const content = els.input.value.trim();
        if ((!content && !pendingImage && !pendingGif) || sending) return;
        sending = true;
        els.sendBtn.disabled = true;
        const form = new FormData();
        form.append('content', content);
        if (pendingImage) form.append('image', pendingImage);
        if (pendingGif) form.append('gif', pendingGif);
        try {
            const { ok, data, status } = await api('/messages', { method: 'POST', body: form });
            if (!ok) {
                showError(els.composerError, status === 403 && data.code === 'no_image_perms' ? NO_IMAGE_PERMS : (data.error || 'Message failed to send.'));
                return;
            }
            els.input.value = '';
            autosize();
            clearPendingImage();
            lastTypingSent = 0;
            appendMessages([data.message], true);
            setMe(data.me);
        } catch (e) {
            showError(els.composerError, 'Message failed to send — check your connection.');
        } finally {
            sending = false;
            els.sendBtn.disabled = false;
            els.input.focus();
        }
    }

    // Photos & GIFs: only for users with the Verified role
    function requireImagePerms() {
        if (me && me.imagePerms) return true;
        showError(els.composerError, NO_IMAGE_PERMS);
        return false;
    }
    function setPendingImage(file) {
        if (!file || !requireImagePerms()) return;
        if (!/^image\/(png|jpeg|gif|webp)$/.test(file.type)) { showError(els.composerError, 'Images must be PNG, JPG, GIF or WebP.'); return; }
        if (file.size > 4 * 1024 * 1024) { showError(els.composerError, 'Images must be under 4 MB.'); return; }
        pendingImage = file;
        pendingGif = null;
        const url = URL.createObjectURL(file);
        els.imagePreview.innerHTML = `<img src="${url}" alt=""><span>${esc(file.name)}</span><button class="cc-icon-btn" aria-label="Remove image">✕</button>`;
        els.imagePreview.querySelector('button').onclick = clearPendingImage;
        els.imagePreview.classList.remove('hidden');
        showError(els.composerError, '');
    }
    function clearPendingImage() {
        pendingImage = null;
        pendingGif = null;
        els.imagePreview.innerHTML = '';
        els.imagePreview.classList.add('hidden');
        els.fileInput.value = '';
    }
    els.uploadBtn.addEventListener('click', () => { if (requireImagePerms()) els.fileInput.click(); });

    // Linked GIFs (Giphy / Tenor / any https .gif link). GIF files can also be uploaded like photos.
    const isGifLink = (v) => /^https:\/\/((media\d*|i)\.giphy\.com|media\d*\.tenor\.com|c\.tenor\.com)\//i.test(v) || /^https:\/\/[^\s?#]+\.gif([?#]\S*)?$/i.test(v);
    function setPendingGif(url) {
        if (!requireImagePerms()) return;
        if (!isGifLink(url)) { showError(els.composerError, 'Paste a direct GIF link (Giphy, Tenor or a link ending in .gif). Right-click a GIF → “Copy image address”.'); return; }
        pendingImage = null;
        els.fileInput.value = '';
        pendingGif = url;
        els.imagePreview.innerHTML = `<img src="${esc(url)}" alt="" referrerpolicy="no-referrer"><span>GIF</span><button class="cc-icon-btn" aria-label="Remove GIF">✕</button>`;
        els.imagePreview.querySelector('button').onclick = clearPendingImage;
        els.imagePreview.classList.remove('hidden');
        showError(els.composerError, '');
    }
    els.gifBtn.addEventListener('click', () => {
        if (!requireImagePerms()) return;
        const url = prompt('Paste a GIF link (Giphy, Tenor or any link ending in .gif):');
        if (url && url.trim()) setPendingGif(url.trim());
    });
    els.fileInput.addEventListener('change', () => setPendingImage(els.fileInput.files[0]));
    els.input.addEventListener('paste', (e) => {
        const file = [...(e.clipboardData?.files || [])].find((f) => f.type.startsWith('image/'));
        if (file) { e.preventDefault(); setPendingImage(file); return; }
        // Pasting just a GIF link attaches it as a GIF instead of plain text.
        const text = (e.clipboardData?.getData('text') || '').trim();
        if (!els.input.value.trim() && isGifLink(text) && me && me.imagePerms) { e.preventDefault(); setPendingGif(text); }
    });
    els.messages.addEventListener('dragover', (e) => e.preventDefault());
    els.messages.addEventListener('drop', (e) => {
        e.preventDefault();
        const file = [...(e.dataTransfer?.files || [])].find((f) => f.type.startsWith('image/'));
        if (file) setPendingImage(file);
    });
    els.list.addEventListener('click', (e) => {
        if (e.target.classList.contains('cc-msg-img')) {
            els.lightbox.querySelector('img').src = e.target.src;
            els.lightbox.classList.remove('hidden');
        }
    });
    els.lightbox.addEventListener('click', () => els.lightbox.classList.add('hidden'));

    // ---------- emoji picker ----------
    const EMOJI = {
        '🕘': ['Recent', []],
        '😀': ['Smileys', '😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 😮‍💨 🤥 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🥵 🥶 🥴 😵 🤯 🤠 🥳 🥸 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 ☠️ 💩 🤡 👹 👺 👻 👽 👾 🤖 😺 😸 😹 😻 😼 😽 🙀 😿 😾'],
        '👋': ['People', '👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦾 🧠 👀 👁️ 👅 👄 🫶 🙋 🙇 🤦 🤷 🧑‍💻 🥷 🧙 🧛 🧟 🧜 🧚'],
        '❤️': ['Hearts', '❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💯 💢 💥 💫 💦 💨 🕳️ 💬 💭 💤 ✨ ⭐ 🌟 🔥 ⚡ 🌈 ☯️'],
        '🐶': ['Nature', '🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐢 🐍 🦖 🐙 🦑 🦀 🐬 🐳 🦈 🐊 🌵 🌲 🌴 🍀 🌸 🌹 🌻 🌙 ☀️ ⛅ ❄️ ☃️ 🌊'],
        '🍕': ['Food', '🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥑 🌶️ 🌽 🥕 🥐 🍞 🧀 🥚 🍳 🥓 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🍜 🍝 🍣 🍱 🍙 🍩 🍪 🎂 🍰 🧁 🍫 🍬 🍭 🍿 🧋 ☕ 🍵 🥤 🧃'],
        '⚽': ['Activities', '⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🥊 🥋 ⛸️ 🛹 🎿 🏆 🥇 🥈 🥉 🏅 🎮 🕹️ 🎲 ♟️ 🎯 🎳 🎤 🎧 🎸 🎹 🥁 🎨 🎬 🎉 🎊 🎁 🎈 🎃 🎄'],
        '💡': ['Objects', '📱 💻 ⌨️ 🖥️ 🖱️ 💾 📷 📺 ⏰ 💡 🔦 📚 📖 ✏️ 📝 📌 📎 🔑 🔒 🔓 🛡️ ⚔️ 🔫 💣 🧨 💎 💰 💸 🚀 🛸 🚗 🏎️ ✈️ 🗿 🏠 🎌 ✅ ❌ ❓ ❗ ⚠️ 🔞 🆒 🆗 🆕 🆙'],
    };
    for (const k in EMOJI) if (typeof EMOJI[k][1] === 'string') EMOJI[k][1] = EMOJI[k][1].split(' ');

    function getRecent() { try { return JSON.parse(localStorage.getItem('yyChatRecentEmoji') || '[]'); } catch (e) { return []; } }
    function pushRecent(emoji) {
        const list = [emoji, ...getRecent().filter((x) => x !== emoji)].slice(0, 24);
        try { localStorage.setItem('yyChatRecentEmoji', JSON.stringify(list)); } catch (e) {}
    }

    function buildPicker(container, onPick) {
        container.innerHTML = `<input class="cc-emoji-search" placeholder="Search emoji by category…"><div class="cc-emoji-tabs"></div><div class="cc-emoji-grid"></div>`;
        const tabs = container.querySelector('.cc-emoji-tabs');
        const grid = container.querySelector('.cc-emoji-grid');
        const search = container.querySelector('.cc-emoji-search');
        function render(filter) {
            EMOJI['🕘'][1] = getRecent();
            grid.innerHTML = '';
            for (const icon in EMOJI) {
                const [label, list] = EMOJI[icon];
                if (!list.length || (filter && !label.toLowerCase().includes(filter))) continue;
                const h = document.createElement('h5');
                h.textContent = label;
                h.dataset.cat = icon;
                grid.appendChild(h);
                list.forEach((emo) => {
                    const b = document.createElement('button');
                    b.type = 'button';
                    b.textContent = emo;
                    b.onclick = (ev) => { ev.stopPropagation(); pushRecent(emo); onPick(emo); };
                    grid.appendChild(b);
                });
            }
        }
        Object.keys(EMOJI).forEach((icon) => {
            const t = document.createElement('button');
            t.type = 'button';
            t.textContent = icon;
            t.title = EMOJI[icon][0];
            t.onclick = (ev) => {
                ev.stopPropagation();
                search.value = '';
                render('');
                const h = grid.querySelector(`h5[data-cat="${icon}"]`);
                if (h) grid.scrollTop = h.offsetTop - grid.offsetTop;
            };
            tabs.appendChild(t);
        });
        search.addEventListener('input', () => render(search.value.trim().toLowerCase()));
        search.addEventListener('click', (ev) => ev.stopPropagation());
        container.render = () => render(search.value.trim().toLowerCase());
        render('');
    }

    buildPicker(els.emojiPicker, (emo) => {
        const start = els.input.selectionStart ?? els.input.value.length;
        const end = els.input.selectionEnd ?? start;
        els.input.value = els.input.value.slice(0, start) + emo + els.input.value.slice(end);
        els.input.selectionStart = els.input.selectionEnd = start + emo.length;
        els.input.focus();
        autosize();
    });
    els.emojiBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        els.emojiPicker.classList.toggle('hidden');
        if (!els.emojiPicker.classList.contains('hidden')) els.emojiPicker.render();
    });

    // ---------- settings ----------
    const s = {
        name: $('ccSetName'), nameHint: $('ccNameHint'), currentPass: $('ccSetCurrentPass'), currentPassWrap: $('ccCurrentPassWrap'), newPass: $('ccSetNewPass'), passLabel: $('ccPassLabel'), passHint: $('ccPassHint'),
        avatarThumb: $('ccAvatarThumb'), bannerThumb: $('ccBannerThumb'),
        avatarUpload: $('ccAvatarUpload'), avatarRemove: $('ccAvatarRemove'), avatarFile: $('ccAvatarFile'),
        bannerColor: $('ccSetBannerColor'), bannerUpload: $('ccBannerUpload'), bannerRemove: $('ccBannerRemove'), bannerFile: $('ccBannerFile'),
        bio: $('ccSetBio'), statusEmoji: $('ccSetStatusEmoji'), statusText: $('ccSetStatusText'), statusPicker: $('ccStatusEmojiPicker'),
        nameColor: $('ccSetNameColor'), gradientOn: $('ccSetGradientOn'), nameGradient: $('ccSetNameGradient'), font: $('ccSetFont'),
        decoGrid: $('ccDecoGrid'), effectGrid: $('ccEffectGrid'), nameFxGrid: $('ccNameFxGrid'), themePrimary: $('ccSetThemePrimary'), themeAccent: $('ccSetThemeAccent'),
        error: $('ccSettingsError'), save: $('ccSettingsSave'), logout: $('ccLogout'), close: $('ccSettingsClose'), preview: $('ccProfilePreview'),
    };
    let draftDecoration = 'none';
    let draftProfileEffect = 'none';
    let draftNameEffect = 'none';
    let draftStatusEmoji = '';

    function draft() {
        return Object.assign({}, me, {
            username: s.name.value.trim() || me.username,
            bannerColor: s.bannerColor.value,
            bio: s.bio.value,
            statusEmoji: draftStatusEmoji,
            statusText: s.statusText.value,
            nameColor: s.nameColor.value,
            nameGradient: s.gradientOn.checked ? s.nameGradient.value : null,
            nameFont: s.font.value,
            decoration: draftDecoration,
            profileEffect: draftProfileEffect,
            nameEffect: draftNameEffect,
            themePrimary: s.themePrimary.value,
            themeAccent: s.themeAccent.value,
        });
    }

    function renderPreview() {
        if (!me) return;
        s.preview.innerHTML = profileCardHtml(draft());
        s.nameGradient.disabled = !s.gradientOn.checked;
        s.statusEmoji.textContent = draftStatusEmoji || '🙂';
        s.decoGrid.querySelectorAll('.cc-deco-opt').forEach((b) => b.classList.toggle('active', b.dataset.deco === draftDecoration));
        s.effectGrid.querySelectorAll('.cc-deco-opt').forEach((b) => b.classList.toggle('active', b.dataset.effect === draftProfileEffect));
        // Name effect tiles show the current (unsaved) name colours.
        const d = draft();
        s.nameFxGrid.querySelectorAll('.cc-deco-opt').forEach((b) => {
            b.classList.toggle('active', b.dataset.fx === draftNameEffect);
            b.querySelector('.cc-fx-sample').innerHTML = nameHtml(Object.assign({}, d, { nameEffect: b.dataset.fx }));
        });
    }

    function buildEffectGrids() {
        s.effectGrid.innerHTML = '';
        Object.entries(PROFILE_EFFECTS).forEach(([key, fx]) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'cc-deco-opt';
            b.dataset.effect = key;
            b.innerHTML = `<span class="cc-effect-icon">${fx.icon}</span>${esc(fx.label)}`;
            b.onclick = () => { draftProfileEffect = key; renderPreview(); };
            s.effectGrid.appendChild(b);
        });
        s.nameFxGrid.innerHTML = '';
        NAME_EFFECTS.forEach((key) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'cc-deco-opt';
            b.dataset.fx = key;
            b.innerHTML = `<span class="cc-fx-sample"></span>${key}`;
            b.onclick = () => { draftNameEffect = key; renderPreview(); };
            s.nameFxGrid.appendChild(b);
        });
    }

    function buildDecoGrid() {
        s.decoGrid.innerHTML = '';
        DECORATIONS.forEach((d) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'cc-deco-opt';
            b.dataset.deco = d;
            b.innerHTML = avatarHtml(Object.assign({}, me, { decoration: d }), 'sm') + d;
            b.onclick = () => { draftDecoration = d; renderPreview(); };
            s.decoGrid.appendChild(b);
        });
    }

    function renderThumbs() {
        s.avatarThumb.style.backgroundImage = me.avatar ? `url('${me.avatar}')` : '';
        s.avatarThumb.textContent = me.avatar ? '' : 'none';
        s.bannerThumb.style.backgroundImage = me.banner ? `url('${me.banner}')` : '';
        s.bannerThumb.style.backgroundColor = me.bannerColor;
        s.bannerThumb.textContent = '';
    }

    function fillSettings() {
        renderThumbs();
        s.name.value = me.username;
        s.nameHint.textContent = me.nextNameChangeAt
            ? `You already changed your name this week. Next change: ${new Date(me.nextNameChangeAt).toLocaleString()}.`
            : 'You can change your name once a week.';
        s.name.disabled = !!me.nextNameChangeAt;
        s.currentPass.value = '';
        s.newPass.value = '';
        s.currentPassWrap.classList.toggle('hidden', !me.hasPassword);
        s.passLabel.textContent = me.hasPassword ? 'Change password' : 'Set a password';
        s.passHint.textContent = me.hasPassword
            ? 'Leave blank to keep your current password. Changing it logs out your other devices.'
            : 'Your account has no password yet — set one so you can log in on other devices.';
        s.bannerColor.value = me.bannerColor;
        s.bio.value = me.bio || '';
        draftStatusEmoji = me.statusEmoji || '';
        s.statusText.value = me.statusText || '';
        s.nameColor.value = me.nameColor;
        s.gradientOn.checked = !!me.nameGradient;
        s.nameGradient.value = me.nameGradient || '#eb459e';
        s.font.value = me.nameFont;
        draftDecoration = me.decoration;
        draftProfileEffect = me.profileEffect || 'none';
        draftNameEffect = me.nameEffect || 'none';
        s.themePrimary.value = me.themePrimary;
        s.themeAccent.value = me.themeAccent;
        s.avatarRemove.disabled = !me.avatar;
        s.bannerRemove.disabled = !me.banner;
        showError(s.error, '');
        buildDecoGrid();
        buildEffectGrids();
        renderPreview();
    }

    function openSettings() {
        if (!me) return;
        fillSettings();
        els.settings.classList.remove('hidden');
    }
    $('ccSettingsBtn').addEventListener('click', openSettings);
    s.close.addEventListener('click', () => els.settings.classList.add('hidden'));
    els.settings.addEventListener('click', (e) => { if (e.target === els.settings) els.settings.classList.add('hidden'); });

    [s.name, s.bannerColor, s.bio, s.statusText, s.nameColor, s.gradientOn, s.nameGradient, s.font, s.themePrimary, s.themeAccent]
        .forEach((el) => el.addEventListener('input', renderPreview));
    s.font.addEventListener('change', renderPreview);
    s.gradientOn.addEventListener('change', renderPreview);

    buildPicker(s.statusPicker, (emo) => { draftStatusEmoji = emo; s.statusPicker.classList.add('hidden'); renderPreview(); });
    s.statusEmoji.addEventListener('click', (e) => {
        e.stopPropagation();
        if (draftStatusEmoji && !s.statusPicker.classList.contains('hidden')) { draftStatusEmoji = ''; renderPreview(); }
        s.statusPicker.classList.toggle('hidden');
        s.statusPicker.render();
    });

    async function uploadMedia(kind, file) {
        if (!file) return;
        if (!/^image\/(png|jpeg|gif|webp)$/.test(file.type)) { showError(s.error, 'Pick a PNG, JPG, GIF or WebP image.'); return; }
        if (file.size > 3 * 1024 * 1024) { showError(s.error, 'Images must be under 3 MB.'); return; }
        const form = new FormData();
        form.append('kind', kind);
        form.append('file', file);
        showError(s.error, '');
        const { ok, data } = await api('/profile', { method: 'POST', body: form });
        if (!ok) { showError(s.error, data.error || 'Upload failed.'); return; }
        setMe(data.user);
        fillSettingsMedia();
    }
    async function removeMedia(kind) {
        const form = new FormData();
        form.append('remove', kind);
        const { ok, data } = await api('/profile', { method: 'POST', body: form });
        if (!ok) { showError(s.error, data.error || 'Could not remove it.'); return; }
        setMe(data.user);
        fillSettingsMedia();
    }
    // Refresh only the media-related bits so unsaved edits in the form are kept.
    function fillSettingsMedia() {
        renderThumbs();
        s.avatarRemove.disabled = !me.avatar;
        s.bannerRemove.disabled = !me.banner;
        buildDecoGrid();
        renderPreview();
    }
    s.avatarUpload.addEventListener('click', () => s.avatarFile.click());
    s.bannerUpload.addEventListener('click', () => s.bannerFile.click());
    s.avatarFile.addEventListener('change', () => { uploadMedia('avatar', s.avatarFile.files[0]); s.avatarFile.value = ''; });
    s.bannerFile.addEventListener('change', () => { uploadMedia('banner', s.bannerFile.files[0]); s.bannerFile.value = ''; });
    s.avatarRemove.addEventListener('click', () => removeMedia('avatar'));
    s.bannerRemove.addEventListener('click', () => removeMedia('banner'));

    s.save.addEventListener('click', async () => {
        const d = draft();
        const body = {
            bannerColor: d.bannerColor, bio: d.bio, statusEmoji: d.statusEmoji, statusText: d.statusText,
            nameColor: d.nameColor, nameGradient: d.nameGradient, nameFont: d.nameFont, decoration: d.decoration,
            profileEffect: d.profileEffect, nameEffect: d.nameEffect,
            themePrimary: d.themePrimary, themeAccent: d.themeAccent,
        };
        if (s.newPass.value) {
            if (s.newPass.value.length < 6) { showError(s.error, 'Passwords must be at least 6 characters.'); return; }
            if (me.hasPassword && !s.currentPass.value) { showError(s.error, 'Enter your current password to change it.'); return; }
            body.newPassword = s.newPass.value;
            body.currentPassword = s.currentPass.value;
        }
        const newName = s.name.value.trim();
        if (newName && newName !== me.username) {
            if (!confirm(`Change your name to "${newName}"? You won't be able to change it again for a week.`)) return;
            body.username = newName;
        }
        s.save.disabled = true;
        showError(s.error, '');
        try {
            const { ok, data } = await api('/profile', { method: 'PATCH', json: body });
            if (!ok) { showError(s.error, data.error || 'Could not save your changes.'); return; }
            setMe(data.user);
            els.settings.classList.add('hidden');
            toast('✅ Profile saved');
        } finally {
            s.save.disabled = false;
        }
    });

    s.logout.addEventListener('click', () => {
        const warn = me && !me.hasPassword ? " You haven't set a password, so you won't be able to log back in — set one first!" : '';
        if (confirm('Log out of the chat?' + warn)) logout(false);
    });

    // ---------- floating button & navigation ----------
    function updateBadge() {
        const total = unread + dmUnreadTotal() + social.incoming.length;
        els.fabBadge.textContent = total > 99 ? '99+' : String(total);
        els.fabBadge.classList.toggle('hidden', !total);
    }
    els.fab.addEventListener('click', () => window.navigateTo('chat'));

    // Used by the site-wide settings panel's "Customize Profile" button.
    window.ccOpenProfileSettings = function () {
        if (me) { openSettings(); return true; }
        window.navigateTo('chat');
        toast('👋 Log in or sign up to customize your profile');
        return false;
    };

    function onNavigate(pageId) {
        const onChat = pageId === 'chat';
        els.fab.classList.toggle('hidden', onChat);
        closePopout();
        if (onChat) {
            unread = 0;
            updateBadge();
            if (me) { enterChat(); } else { showLogin(); }
        }
    }
    const originalNavigate = window.navigateTo;
    window.navigateTo = function (pageId) {
        originalNavigate(pageId);
        onNavigate(pageId);
    };

    // ---------- boot ----------
    (async function init() {
        renderHistoryStatus();
        if (!token) { showLogin(); return; }
        try {
            const { ok, data } = await api('/me');
            if (!ok) { if (!token) return; showLogin(); return; }
            setMe(data.user);
            if (isChatPage()) enterChat();
            else startPolling(); // light background polling for the unread badge
        } catch (e) {
            showLogin();
        }
    })();
})();
